//
//  Untitled.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import SwiftUI

// 🔥 Workout Plan Card
struct WorkoutPlanCard: View {
    var title: String
    var duration: String

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.headline)
                .bold()
                .foregroundColor(.white)

            HStack {
                Text("Duration: \(duration)")
                    .foregroundColor(.gray)
                Spacer()
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.black.opacity(0.8)]),
                startPoint: .leading,
                endPoint: .trailing
            )
        )
        .cornerRadius(15)
        .padding(.horizontal, 10)
    }
}

// 🔥 Workout Detail Popup
struct WorkoutDetailPopup: View {
    var workout: WorkoutHistory

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(spacing: 20) {
                Text(workout.exerciseType)
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.top, 20)

                StatBox(icon: "clock.fill", title: "Total Time", value: workout.totalTime)
                StatBox(icon: "map.fill", title: "Distance", value: "\(String(format: "%.2f", workout.distance)) km")
                StatBox(icon: "flame.fill", title: "Calories", value: "\(String(format: "%.0f", workout.calories)) kcal")
                StatBox(icon: "speedometer", title: "Avg Pace", value: "\(String(format: "%.2f", workout.pace)) min/km")

                Spacer()
            }
            .padding()
        }
    }
}
