//
//  HistoryView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
import SwiftUI
import FirebaseFirestore
import FirebaseAuth


struct HistoryView: View {
    @State private var selectedDate = Date()
    @State private var workoutHistory: [WorkoutHistory] = []
    @State private var selectedWorkout: WorkoutHistory? = nil // ✅ For popup

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(spacing: 15) {
                Text("Calendar")
                    .font(.headline)
                    .foregroundColor(.white)

                // 🔥 Calendar
                ZStack(alignment: .bottom) {
                    DatePicker("", selection: $selectedDate, displayedComponents: .date)
                        .datePickerStyle(.graphical)
                        .accentColor(.yellow)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.black.opacity(0.3))
                        )
                        .padding(.horizontal)
                        .colorScheme(.dark)


                }

                Text("Workout History")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding(.top, 10)

                // 🔥 List of workouts
                ScrollView {
                    VStack(spacing: 10) {
                        if workoutsForSelectedDate().isEmpty {
                            Text("No workout recorded.")
                                .foregroundColor(.gray)
                                .padding(.top, 30)
                        } else {
                            ForEach(workoutsForSelectedDate()) { workout in
                                Button(action: {
                                    selectedWorkout = workout // ✅ Tap to show details
                                }) {
                                    WorkoutPlanCard(
                                        title: workout.exerciseType,
                                        duration: workout.totalTime
                                    )
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 10)
                }
            }
            .padding()
        }
        .onAppear {
            fetchWorkoutHistory()
        }
        .sheet(item: $selectedWorkout) { workout in
            WorkoutDetailPopup(workout: workout)
        } // ✅ Pop up detail
    }

    // 🔥 Filter workouts matching the selected date
    private func workoutsForSelectedDate() -> [WorkoutHistory] {
        workoutHistory.filter { Calendar.current.isDate($0.date, inSameDayAs: selectedDate) }
    }

    // 🔥 Fetch workout history from Firestore
    private func fetchWorkoutHistory() {
        guard let user = Auth.auth().currentUser else { return }

        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)

        userRef.getDocument { document, error in
            if let document = document, document.exists {
                if let data = document.data(),
                   let workouts = data["workoutHistory"] as? [[String: Any]] {

                    self.workoutHistory = workouts.compactMap { workoutDict in
                        guard
                            let timestamp = workoutDict["date"] as? Timestamp,
                            let exerciseType = workoutDict["exerciseType"] as? String,
                            let totalTime = workoutDict["totalTime"] as? String,
                            let distance = workoutDict["distance"] as? Double,
                            let calories = workoutDict["calories"] as? Double,
                            let pace = workoutDict["pace"] as? Double
                        else { return nil }

                        return WorkoutHistory(
                            date: timestamp.dateValue(),
                            exerciseType: exerciseType,
                            totalTime: totalTime,
                            distance: distance,
                            calories: calories,
                            pace: pace
                        )
                    }
                }
            }
        }
    }
}





// 🔥 Preview
struct HistoryView_Previews: PreviewProvider {
    static var previews: some View {
        HistoryView()
    }
}

