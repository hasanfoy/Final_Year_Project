//
//  navigaitonManager.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//

import Foundation
import SwiftUI
import CoreMotion
import FirebaseAuth
import FirebaseFirestore

class ExerciseViewModel: ObservableObject {
    @Published var selectedExercise: String = ""
    @Published var userWeight: Double = 0.0 
    @Published var selectedOption: String = "Time"
    @Published var time: Int = 30
    @Published var distance: Double = 2.0
    
    @Published var elapsedTime: Int = 0
    @Published var walkedDistance: Double = 0.0
    @Published var caloriesBurned: Double = 0.0
    @Published var pace: Double = 0.0
    @Published var isRunning: Bool = false
    @Published var stepCount: Int = 0
    @Published var showSummary: Bool = false
    @Published var isLoadingWeight: Bool = true // ✅ For loading indicator

    private var timer: Timer?
    private let pedometer = CMPedometer()
    
    init() {
        fetchUserWeight() // ✅ Fetch user's weight when ViewModel created
    }
    
    func fetchUserWeight() {
        isLoadingWeight = true // Start loading
        
        guard let user = Auth.auth().currentUser else {
            print("❌ No authenticated user.")
            isLoadingWeight = false
            return
        }
        
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)
        
        userRef.getDocument { document, error in
            DispatchQueue.main.async {
                self.isLoadingWeight = false // Stop loading
                
                if let document = document, document.exists {
                    let data = document.data()
                    if let latestWeight = data?["currentWeight"] as? Double ?? data?["weight"] as? Double {
                        self.userWeight = latestWeight
                        print("✅ Fetched user weight: \(self.userWeight) kg")
                    }
                } else {
                    print("❌ Error fetching user weight: \(error?.localizedDescription ?? "Unknown error")")
                }
            }
        }
    }
    
    func prepareForWorkout() {
        elapsedTime = 0
        walkedDistance = 0.0
        caloriesBurned = 0.0
        pace = 0.0
        isRunning = false
        stepCount = 0
    }
    
    func startWorkout() {
        guard !isRunning else { return }
        isRunning = true
        
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            DispatchQueue.main.async {
                self.elapsedTime += 1
                self.updatePace()
                self.calculateCalories()
                self.checkWorkoutProgress()
            }
        }
        
        startPedometer()
    }
    
    func pauseWorkout() {
        timer?.invalidate()
        pedometer.stopUpdates()
        isRunning = false
    }
    
    func resumeWorkout() {
        startWorkout()
    }
    
    func stopWorkout() {
        timer?.invalidate()
        pedometer.stopUpdates()
        isRunning = false
    }
    
    func checkWorkoutProgress() {
        if selectedOption == "Time" && elapsedTime >= (time * 60) {
            endWorkout()
        } else if selectedOption == "Distance" && walkedDistance >= distance {
            endWorkout()
        }
    }
    
    func endWorkout() {
        stopWorkout()
        showSummary = true
    }
    
    func startPedometer() {
        if CMPedometer.isDistanceAvailable() {
            pedometer.startUpdates(from: Date()) { data, _ in
                DispatchQueue.main.async {
                    guard let data = data else { return }
                    self.stepCount = data.numberOfSteps.intValue
                    
                    if let pedometerDistance = data.distance {
                        self.walkedDistance = pedometerDistance.doubleValue / 1000.0
                        self.updatePace()
                        self.calculateCalories()
                    }
                }
            }
        }
    }

    func calculateCalories() {
        guard isRunning else { return }

        switch selectedExercise {
        case "Walking":
            caloriesBurned = userWeight * walkedDistance * 0.57
        case "Running":
            caloriesBurned = userWeight * walkedDistance * 0.9
        case "Hiking":
            caloriesBurned = userWeight * walkedDistance * 0.62
        case "Swimming":
            let minutesElapsed = Double(elapsedTime) / 60.0
            caloriesBurned = minutesElapsed * 10
        case "Push ups":
            let minutesElapsed = Double(elapsedTime) / 60.0
            caloriesBurned = minutesElapsed * 8
        default:
            caloriesBurned = 0
        }
    }
    
    func updatePace() {
        if walkedDistance > 0 && elapsedTime > 0 && isRunning {
            pace = (Double(elapsedTime) / 60) / walkedDistance
        } else {
            pace = 0.0
        }
    }
    // MARK: - 🔥 Save Workout History to Firestore
    func saveWorkoutHistory(completion: @escaping (Bool) -> Void) {
        guard let user = Auth.auth().currentUser else {
            print("❌ No authenticated user to save history.")
            completion(false)
            return
        }
        
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)
        
        // Prepare workout summary data
        let workoutData: [String: Any] = [
            "date": Timestamp(date: Date()),
            "exerciseType": selectedExercise,
            "totalTime": formattedElapsedTime,
            "distance": walkedDistance,
            "calories": caloriesBurned,
            "pace": totalPace
        ]
        
        // Add workout to workoutHistory array
        userRef.updateData([
            "workoutHistory": FieldValue.arrayUnion([workoutData])
        ]) { error in
            if let error = error {
                print("❌ Failed to save workout history: \(error.localizedDescription)")
                completion(false)
            } else {
                print("✅ Workout history saved successfully!")
                completion(true)
            }
        }
    }

    
    var totalPace: Double {
        if walkedDistance > 0 && elapsedTime > 0 {
            return (Double(elapsedTime) / 60) / walkedDistance
        } else {
            return 0.0
        }
    }
    
    var formattedElapsedTime: String {
        String(format: "%02d:%02d", elapsedTime / 60, elapsedTime % 60)
    }
    
    var formattedTimeLeft: String {
        let remainingTime = max((time * 60) - elapsedTime, 0)
        return String(format: "%02d:%02d", remainingTime / 60, remainingTime % 60)
    }
    
    var elapsedDistanceFormatted: String {
        String(format: "%.2f km", walkedDistance)
    }
    
    var progress: Double {
        selectedOption == "Time"
            ? Double(elapsedTime) / Double(time * 60)
            : walkedDistance / distance
    }
}





