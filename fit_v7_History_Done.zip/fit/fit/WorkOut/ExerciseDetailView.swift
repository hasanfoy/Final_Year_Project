//
//  ExerciseDetailView.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//
import SwiftUI

struct ExerciseDetailView: View {
    @EnvironmentObject var exerciseVM: ExerciseViewModel
    @EnvironmentObject var navigationManager: NavigationManager

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()
            
            VStack(spacing: 20) {
                // **Back Button**
                HStack {
                    Button(action: {
                        navigationManager.popToRoot()
                    }) {
                        Image(systemName: "arrow.left")
                            .foregroundColor(.white)
                            .padding()
                    }
                    Spacer()
                }
                
                Text("Choose Workout Mode")
                    .font(.title2)
                    .foregroundColor(.white)

                Picker("Mode", selection: $exerciseVM.selectedOption) {
                    Text("Time").tag("Time")
                    Text("Distance").tag("Distance")
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                if exerciseVM.selectedOption == "Time" {
                    VStack {
                        Text("Set Time (minutes)")
                            .foregroundColor(.white)
                        TextField("Enter time", value: $exerciseVM.time, formatter: NumberFormatter())
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .padding()
                    }
                } else {
                    VStack {
                        Text("Set Distance (km)")
                            .foregroundColor(.white)
                        TextField("Enter distance", value: $exerciseVM.distance, formatter: NumberFormatter())
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                            .padding()
                    }
                }

                Button(action: {
                    exerciseVM.prepareForWorkout()
                    navigationManager.push("ExerciseTracking:\(exerciseVM.selectedExercise)")
                }) {
                    Text("Start Workout")
                        .bold()
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding(.top, 20)

                Spacer()
            }
            .padding()
        }
        .navigationBarBackButtonHidden(true)
    }
}



// **Preview**
struct ExerciseDetailView_Previews: PreviewProvider {
    static var previews: some View {
        let exerciseVM = ExerciseViewModel()
        let navigationManager = NavigationManager()

        return ExerciseDetailView()
            .environmentObject(exerciseVM)
            .environmentObject(navigationManager)
    }
}





