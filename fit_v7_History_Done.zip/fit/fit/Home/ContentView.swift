//
//  ContentView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var showSplash = true // ✅ Control Splash visibility

    var body: some View {
        ZStack {
            if showSplash {
                SplashScreenView()
            } else {
                NavigationStack {
                    if authViewModel.isLoggedIn {
                        CustomTabBarView() // ✅ If logged in
                    } else {
                        LoginView() // ✅ Otherwise login
                    }
                }
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation {
                    showSplash = false
                }
            }
        }
    }
}

// 🔥 Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AuthViewModel())
    }
}


