//
//  updatedWeight.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import SwiftUI

struct UpdateWeightHeightView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var newWeight: String = ""
    @State private var newHeight: String = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Update Your Info")
                .font(.title)
                .bold()
            
            TextField("New Weight (kg)", text: $newWeight)
                .keyboardType(.decimalPad)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(8)
            
            TextField("New Height (cm)", text: $newHeight)
                .keyboardType(.decimalPad)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(8)
            
            Button(action: {
                updateUserInfo()
            }) {
                Text("Save Changes")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(8)
            }
            .padding(.top, 20)
        }
        .padding()
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Update Info"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    private func updateUserInfo() {
        guard let weightValue = Double(newWeight) else {
            alertMessage = "Please enter a valid weight."
            showAlert = true
            return
        }
        
        guard let heightValue = Double(newHeight) else {
            alertMessage = "Please enter a valid height."
            showAlert = true
            return
        }
        
        // ✅ Now both weight and height are valid Double values!
        authViewModel.updateWeightAndHeight(newWeight: weightValue, newHeight: heightValue) { success, errorMessage in
            if success {
                alertMessage = "Successfully updated weight and height!"
            } else {
                alertMessage = errorMessage ?? "Unknown error"
            }
            showAlert = true
            
            // OPTIONAL: Refresh user data if needed
            authViewModel.fetchLatestUserInfo()
        }
    }
}
