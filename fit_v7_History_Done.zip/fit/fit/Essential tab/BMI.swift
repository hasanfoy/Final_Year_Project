//
//  BMI.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//
import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct BMICalculatorView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var heightText: String = ""
    @State private var weightText: String = ""
    @State private var calculatedBMI: Double?
    @State private var bmiStatus: String = ""
    @State private var adviceMessage: String = ""
    @State private var showSaveAlert = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea() // 🖤 Dark background
            
            ScrollView {
                VStack(spacing: 20) {
                    Text("BMI Calculator")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                    
                    if let bmi = calculatedBMI {
                        VStack(spacing: 10) {
                            Text(String(format: "%.1f", bmi))
                                .font(.system(size: 50))
                                .bold()
                                .foregroundColor(.white)
                            
                            Text(bmiStatus)
                                .font(.title3)
                                .bold()
                                .foregroundColor(.green) // ✅ Status color
                        }
                        .frame(width: 200, height: 150)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.black]), startPoint: .top, endPoint: .bottom))
                        .cornerRadius(20)
                    }
                    
                    if !adviceMessage.isEmpty {
                        Text(adviceMessage)
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.purple.opacity(0.7), lineWidth: 1)
                            )
                            .padding(.horizontal, 30)
                    }
                    
                    VStack(spacing: 15) {
                        // 👉 Custom styled TextField for Height
                        TextField("Height (cm)", text: $heightText)
                            .keyboardType(.decimalPad)
                            .padding()
                            .background(Color.gray.opacity(0.3)) // 🖤 Gray field
                            .cornerRadius(10)
                            .foregroundColor(.white) // ⚪ White text
                            .accentColor(.purple)
                        
                        // 👉 Custom styled TextField for Weight
                        TextField("Weight (kg)", text: $weightText)
                            .keyboardType(.decimalPad)
                            .padding()
                            .background(Color.gray.opacity(0.3))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .accentColor(.purple)
                        
                        // 👉 Calculate BMI Button
                        Button(action: calculateBMI) {
                            Text("Calculate BMI")
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.purple)
                                .cornerRadius(10)
                        }
                        
                        // 👉 Save Changes Button
                        Button(action: saveUpdatedInfo) {
                            Text("Save Changes")
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.green)
                                .cornerRadius(10)
                        }
                    }
                    .padding()
                    
                    Spacer(minLength: 100) // Adds space so keyboard doesn't cover buttons
                }
                .padding()
            }
            .scrollDismissesKeyboard(.interactively) // 👈 Keyboard hides when user scrolls
        }
        .onAppear {
            loadCurrentUserInfo()
        }
        .alert(isPresented: $showSaveAlert) {
            Alert(
                title: Text("Saved!"),
                message: Text("Your weight and height have been updated successfully."),
                dismissButton: .default(Text("OK"))
            )
        }
    }
    
    private func loadCurrentUserInfo() {
        guard let user = authViewModel.user else { return }
        
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)
        
        userRef.getDocument { document, error in
            if let document = document, document.exists {
                let data = document.data()
                if let height = data?["height"] as? Double {
                    self.heightText = String(format: "%.0f", height)
                }
                if let weight = data?["currentWeight"] as? Double ?? data?["weight"] as? Double {
                    self.weightText = String(format: "%.0f", weight)
                }
                if let height = Double(heightText), let weight = Double(weightText) {
                    self.calculatedBMI = calculateBMIValue(height: height, weight: weight)
                    updateBMIStatusAndAdvice(bmi: self.calculatedBMI!)
                }
            }
        }
    }
    
    private func calculateBMI() {
        guard let height = Double(heightText), let weight = Double(weightText) else {
            print("❌ Invalid input.")
            return
        }
        calculatedBMI = calculateBMIValue(height: height, weight: weight)
        updateBMIStatusAndAdvice(bmi: calculatedBMI!)
    }
    
    private func calculateBMIValue(height: Double, weight: Double) -> Double {
        let heightInMeters = height / 100 // Convert cm to meters
        guard heightInMeters != 0 else { return 0 }
        return weight / (heightInMeters * heightInMeters)
    }
    
    private func updateBMIStatusAndAdvice(bmi: Double) {
        switch bmi {
        case ..<18.5:
            bmiStatus = "Underweight"
            adviceMessage = "You should eat more nutritious food and consider consulting a doctor."
        case 18.5..<25:
            bmiStatus = "Normal"
            adviceMessage = "You are in the perfect shape. Keep it up!"
        case 25..<30:
            bmiStatus = "Overweight"
            adviceMessage = "A little exercise and balanced diet could help you a lot!"
        default:
            bmiStatus = "Obese"
            adviceMessage = "It's recommended to consult a healthcare provider for guidance."
        }
    }
    
    private func saveUpdatedInfo() {
        guard let newWeight = Double(weightText), let newHeight = Double(heightText) else {
            print("❌ Invalid weight or height.")
            return
        }
        
        authViewModel.updateWeightAndHeight(newWeight: newWeight, newHeight: newHeight) { success, errorMessage in
            if success {
                showSaveAlert = true
                print("✅ Successfully updated weight and height!")
            } else {
                print("❌ Failed to update: \(errorMessage ?? "Unknown error")")
            }
        }
    }
}


struct BMICalculatorView_Previews: PreviewProvider {
    static var previews: some View {
        BMICalculatorView()
            .environmentObject(AuthViewModel()) 
    }
}

