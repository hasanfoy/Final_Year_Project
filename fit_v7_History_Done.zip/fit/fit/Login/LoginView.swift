//
//  LoginView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//
import SwiftUI

struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var navigateToSignUp = false
    @State private var navigateToForgotPassword = false
    @State private var navigateToHome = false
    @State private var isSignUpTapped = false
    @State private var showAlert = false
    @State private var errorMessage: String? = nil
    @EnvironmentObject var authViewModel: AuthViewModel

    var body: some View {
        NavigationStack {
            ZStack {
                // **Background Image**
                Image("login")
                    .resizable()
                    .ignoresSafeArea(edges: .all)
                    .overlay(Color.black.opacity(0.5))

                VStack {
                    // **Sign Up Button (Top Right)**
                    HStack {
                        Spacer()
                        Button(action: {
                            isSignUpTapped = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                navigateToSignUp = true
                            }
                        }) {
                            Text("Sign Up")
                                .font(.headline)
                                .foregroundColor(isSignUpTapped ? .green : .white)
                                .padding(10)
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .trailing)

                    Spacer()

                    // **Welcome Message**
//                    Text("Welcome Back.")
//                        .font(.title2)
//                        .fontWeight(.semibold)
//                        .foregroundColor(.white)
//                        .padding(.bottom, 300)

                    VStack(alignment: .leading, spacing: 20) {
                        // **Email Field**
                        HStack {
                            Text("Email:")
                                .foregroundColor(.white)
                                .font(.headline)

                            TextField("", text: $email)
                                .foregroundColor(.white)
                                .textFieldStyle(PlainTextFieldStyle())
                                .autocapitalization(.none)
                                .keyboardType(.emailAddress)
                        }
                        .padding(.vertical, 10)
                        .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)
                        .frame(maxWidth: 300)

                        // **Password Field**
                        HStack {
                            Text("Password:")
                                .foregroundColor(.white)
                                .font(.headline)

                            SecureField("", text: $password)
                                .foregroundColor(.white)
                                .textFieldStyle(PlainTextFieldStyle())
                        }
                        .padding(.vertical, 10)
                        .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)
                        .frame(maxWidth: 300)
                    }
                    .padding(.horizontal, 30)

                    if let error = errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .font(.caption)
                            .padding(.top, 5)
                    }

                    // **Forgot Password**
                    HStack {
                        Spacer()
                        Button(action: {
                            navigateToForgotPassword = true
                        }) {
                            Text("Forgot Password?")
                                .foregroundColor(.white)
                                .font(.caption)
                        }
                    }
                    .frame(maxWidth: 300)
                    .padding(.bottom, 10)
                    .padding(.top, 10)

                    // **Login Button**
                    Button(action: { handleLogin() }) {
                        Text("Log in")
                            .foregroundColor(.white)
                            .frame(width: 300)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(25)
                    }
                    .padding(.top, 30)
                    .padding(.bottom, 50)
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Login Error"), message: Text(errorMessage ?? ""), dismissButton: .default(Text("OK")))
                    }

                    // ✅ Use NavigationLink Instead of navigationDestination
                    .navigationDestination(isPresented: $navigateToHome) {
                        CustomTabBarView()
                    }
                    .navigationDestination(isPresented: $navigateToSignUp) {
                        SignUpView()
                    }
                    .navigationDestination(isPresented: $navigateToForgotPassword) {
                        ForgotPasswordView()
                    }

                }
            }
        }
    }

    // **Handles login authentication**
    private func handleLogin() {
        authViewModel.login(email: email, password: password) { success, error in
            if success {
                navigateToHome = true // ✅ Uses NavigationLink now
            } else {
                self.errorMessage = error
                self.showAlert = true
            }
        }
    }
}



// 🔥 Preview for LoginView
struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
            .environmentObject(AuthViewModel()) // Provide Environment Object
    }
}


