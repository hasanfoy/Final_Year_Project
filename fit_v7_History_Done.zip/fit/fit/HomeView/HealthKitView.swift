//
//  HealthKitView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//

import SwiftUI
import HealthKit

struct HealthKitView: View {
    @StateObject private var healthKitManager = HealthKitManager()
    @State private var showingSettings = false // ✅ Controls settings page visibility
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(Color(hex: "050723"))
                                .frame(height: 200)
                                .frame(maxWidth: .infinity)
                .overlay(
                    VStack(spacing: 12) {
                        // 🔥 Step Count Section
                        VStack {
                            Image(systemName: "shoeprints.fill")
                                .font(.system(size: 30))
                                .foregroundColor(.green)

                            Text("\(Int(healthKitManager.stepProgress))/\(Int(healthKitManager.stepsGoal)) steps")
                                .foregroundColor(.white)
                                .font(.title3)
                                .bold()

                            ProgressView(value: healthKitManager.stepProgress / healthKitManager.stepsGoal)
                                .progressViewStyle(LinearProgressViewStyle())
                                .frame(width: 250, height: 6)
                                .tint(.green)
                                .background(Color.gray.opacity(0.3))
                                .cornerRadius(3)
                        }

                        Divider().background(Color.white.opacity(0.3))

                        // 🔥 Rings Section (Distance, Calories, Active Hours)
                        HStack(spacing: 25) {
                            ActivityRing(progress: healthKitManager.distanceProgress / healthKitManager.distanceGoal, icon: "figure.walk", color: .white, size: 60, label: "\(String(format: "%.2f", healthKitManager.distanceProgress))/\(Int(healthKitManager.distanceGoal)) mi")

                            ActivityRing(progress: healthKitManager.moveProgress / healthKitManager.caloriesGoal, icon: "flame.fill", color: .red, size: 60, label: "\(Int(healthKitManager.moveProgress))/\(Int(healthKitManager.caloriesGoal)) kcal")

                            ActivityRing(progress: healthKitManager.activeHourProgress / healthKitManager.activeHourGoal, icon: "clock.fill", color: .mint, size: 60, label: "\(Int(healthKitManager.activeHourProgress))/\(Int(healthKitManager.activeHourGoal)) hrs")
                        }
                    }
                    .padding()
                )
        }
        .padding(.horizontal, 20)
        .onTapGesture { // ✅ Opens settings when tapped
            showingSettings = true
        }
        .fullScreenCover(isPresented: $showingSettings) { // ✅ Full-screen settings page
            HealthKitSettingsView(
                caloriesGoal: healthKitManager.caloriesGoal,
                stepsGoal: healthKitManager.stepsGoal,
                distanceGoal: healthKitManager.distanceGoal,
                activeHourGoal: healthKitManager.activeHourGoal, // ✅ Updated
                onSave: { newCalories, newSteps, newDistance, newActiveHours in
                    healthKitManager.updateGoals(calories: newCalories, steps: newSteps, distance: newDistance, activeHours: newActiveHours)
                }
            )
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                healthKitManager.requestAuthorization()
            }
        }
    }
}

struct ActivityRing: View {
    var progress: Double
    var icon: String
    var color: Color
    var size: CGFloat
    var label: String
    
    var body: some View {
        VStack {
            ZStack {
                Circle()
                    .stroke(color.opacity(0.2), lineWidth: 8)
                    .frame(width: size, height: size)
                
                Circle()
                    .trim(from: 0.0, to: CGFloat(min(progress, 1.0)))
                    .stroke(color, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    .rotationEffect(Angle(degrees: -90))
                    .frame(width: size, height: size)
                
                Image(systemName: icon)
                    .font(.system(size: 30))
                    .foregroundColor(color)
            }
            
            Text(label)
                .foregroundColor(.white)
                .font(.caption)
        }
    }
}



struct HealthKitSettingsView: View {
    @State var caloriesGoal: Double
    @State var stepsGoal: Double
    @State var distanceGoal: Double
    @State var activeHourGoal: Double
    
    var onSave: (Double, Double, Double, Double) -> Void
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            // ✅ Back Button
            HStack {
                Button(action: { presentationMode.wrappedValue.dismiss() }) {
                    Image(systemName: "arrow.left")
                        .font(.title2)
                        .foregroundColor(.white)
                }
                Spacer()
            }
            .padding(.horizontal)

            Text("Set Your Goals")
                .font(.title2)
                .foregroundColor(.white)
                .bold()
                .padding()

            ScrollView { // ✅ Fix for keyboard issue
                VStack(spacing: 20) {
                    GoalInputView(title: "Calories Goal (kcal)", value: $caloriesGoal)
                    GoalInputView(title: "Steps Goal", value: $stepsGoal)
                    GoalInputView(title: "Distance Goal (km)", value: $distanceGoal)
                    GoalInputView(title: "Active hours Goal (hours)", value: $activeHourGoal)
                }
                .padding()
            }

            Button(action: {
                onSave(caloriesGoal, stepsGoal, distanceGoal, activeHourGoal)
                presentationMode.wrappedValue.dismiss()
            }) {
                Text("Save Goals")
                    .foregroundColor(.black)
                    .bold()
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(10)
            }
            .padding()
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(hex: "050723").ignoresSafeArea())
    }
}

struct GoalInputView: View {
    var title: String
    @Binding var value: Double

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .foregroundColor(.white)
                .font(.headline)

            TextField("Enter value", value: $value, formatter: NumberFormatter())
                .keyboardType(.decimalPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
        }
        .padding(.horizontal)
    }
}


// MARK: - 🔍 Preview
struct HealthKitView_Previews: PreviewProvider {
    static var previews: some View {
        HealthKitView()
            .background(Color.black)
    }
}



