//
//  GoalModel.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import Foundation
import FirebaseCore

struct Goal: Identifiable, Codable, Hashable {
    var id: String
    var title: String
    var description: String
    var createdAt: Date
    
    init(id: String, title: String, description: String, createdAt: Date) {
        self.id = id
        self.title = title
        self.description = description
        self.createdAt = createdAt
    }
    
    init?(dict: [String: Any]) {
        guard let id = dict["id"] as? String,
              let title = dict["title"] as? String,
              let description = dict["description"] as? String,
              let timestamp = dict["createdAt"] as? Timestamp else {
            return nil
        }
        self.id = id
        self.title = title
        self.description = description
        self.createdAt = timestamp.dateValue()
    }
    
    func toDict() -> [String: Any] {
        return [
            "id": id,
            "title": title,
            "description": description,
            "createdAt": createdAt
        ]
    }
}
