//
//  SplashScreenView.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//
import SwiftUI

struct SplashScreenView: View {
    @State private var animateText = false
    @State private var typingText = ""
    private let fullText = "Don’t quit, Stay fit."

    var body: some View {
        ZStack {
            Image("splash")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()

            VStack {
                Spacer()

                VStack(spacing: 10) {
                    if animateText {
                        Text("Welcome")
                            .font(.title)
                            .foregroundColor(.white)
                            .transition(.move(edge: .bottom).combined(with: .opacity))

                        Text("To")
                            .font(.title)
                            .foregroundColor(.white)
                            .transition(.move(edge: .bottom).combined(with: .opacity))

                        Text("FitBody")
                            .font(.largeTitle)
                            .bold()
                            .italic()
                            .foregroundColor(.blue)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .animation(.easeOut(duration: 0.8), value: animateText)

                Spacer()

                Text(typingText)
                    .font(.footnote)
                    .foregroundColor(.white)
                    .padding(.bottom, 1)
                    .overlay(
                        Rectangle()
                            .frame(height: 3)
                            .foregroundColor(.blue)
                            .offset(y: 10),
                        alignment: .bottom
                    )
            }
            .padding()
        }
        .onAppear {
            withAnimation {
                animateText = true
            }
            startTypingEffect()
        }
    }

    private func startTypingEffect() {
        typingText = ""
        var charIndex = 0.0
        for letter in fullText {
            DispatchQueue.main.asyncAfter(deadline: .now() + charIndex * 0.07) {
                typingText.append(letter)
            }
            charIndex += 1
        }
    }
}

// 🔥 Preview
struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
    }
}

