//
//  SateboxView.swift
//  fit
//
//  Created by Foysal Hasan on 17/02/2025.
//
import SwiftUI

struct StatBox: View {
    var icon: String
    var title: String
    var value: String

    init(icon: String, title: String, value: String) {
        self.icon = icon
        self.title = title
        self.value = value
    }

    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: icon)
                .foregroundColor(.white)
                .font(.system(size: 24))

            VStack(alignment: .leading) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(.gray)

                Text(value)
                    .font(.headline)
                    .foregroundColor(.white)
            }

            Spacer()
        }
        .padding()
        .frame(height: 60)
        .background(Color.black.opacity(0.3))
        .cornerRadius(12)
    }
}


