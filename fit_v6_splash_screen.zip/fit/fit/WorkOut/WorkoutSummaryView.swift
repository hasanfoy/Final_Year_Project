//
//  WorkoutSummaryView.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//
import SwiftUI

struct WorkoutSummaryView: View {
    @EnvironmentObject var exerciseVM: ExerciseViewModel
    @EnvironmentObject var navigationManager: NavigationManager

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Workout Summary").font(.title2).foregroundColor(.white)

                VStack(spacing: 15) {
                    StatBox(icon: "clock.fill", title: "Total Time", value: exerciseVM.formattedElapsedTime)
                    StatBox(icon: "map.fill", title: "Total Distance", value: exerciseVM.elapsedDistanceFormatted)
                    StatBox(icon: "flame.fill", title: "Calories", value: String(format: "%.1f kcal", exerciseVM.caloriesBurned))
                    StatBox(icon: "speedometer", title: "Avg Pace", value: String(format: "%.2f min/km", exerciseVM.totalPace))

                }
                .padding(.horizontal)

                Button("Done") {
                    navigationManager.popToRoot()
                }
                .foregroundColor(.white)
                .padding()
                .background(Color.blue)
                .cornerRadius(10)

                Spacer()
            }
            .padding()
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct WorkoutSummaryView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutSummaryView()
            .environmentObject(ExerciseViewModel())
            .environmentObject(NavigationManager())
    }
}







