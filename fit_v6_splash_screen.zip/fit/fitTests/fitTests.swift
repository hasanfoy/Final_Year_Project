//
//  fitTests.swift
//  fitTests
//
//  Created by Foysal Hasan on 08/02/2025.
//

import Testing
@testable import fit

struct fitTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
