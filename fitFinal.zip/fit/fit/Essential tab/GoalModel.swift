//
//  GoalModel.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import Foundation
import FirebaseFirestore

// MARK: - Model for Goal
struct Goal: Identifiable, Codable, Hashable {
    var id: String
    var title: String
    var description: String
    var createdAt: Date

    // MARK: - Designated Initializer
    init(id: String, title: String, description: String, createdAt: Date) {
        self.id = id
        self.title = title
        self.description = description
        self.createdAt = createdAt
    }

    // MARK: - Default Empty Initializer
    init() {
        self.id = UUID().uuidString
        self.title = ""
        self.description = ""
        self.createdAt = Date()
    }

    // MARK: - Firebase Dictionary Initializer
    init?(dict: [String: Any]) {
        guard let id = dict["id"] as? String,
              let title = dict["title"] as? String,
              let description = dict["description"] as? String,
              let timestamp = dict["createdAt"] as? Timestamp else {
            return nil
        }
        self.id = id
        self.title = title
        self.description = description
        self.createdAt = timestamp.dateValue()
    }

    // MARK: - Convert to Dictionary for Firestore
    func toDict() -> [String: Any] {
        return [
            "id": id,
            "title": title,
            "description": description,
            "createdAt": Timestamp(date: createdAt)
        ]
    }

    // MARK: - Static Placeholder Instance
    static let empty = Goal()
}


//MARK: Model for Weight Entry
struct WeightEntry: Identifiable {
    var id = UUID()
    var weight: Double
    var date: Date
}

