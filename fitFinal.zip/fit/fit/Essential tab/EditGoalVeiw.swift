//
//  EditGoalVeiw.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//
import SwiftUI
import FirebaseFirestore
import FirebaseAuth

// MARK: - Edit Goal View
struct EditGoalView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var authViewModel: AuthViewModel
    @State var goal: Goal = .empty
    var isNewGoal: Bool
    var onSave: () -> Void

    @FocusState private var isDescriptionFocused: Bool // Track TextEditor focus

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Title")
                        .foregroundColor(.white)
                        .font(.headline)
                        .padding(.horizontal)

                    TextField("Enter your goal title", text: $goal.title)
                        .padding()
                        .background(Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)

                    Text("Description")
                        .foregroundColor(.white)
                        .font(.headline)
                        .padding(.horizontal)

                    TextEditor(text: $goal.description)
                        .padding()
                        .frame(height: 200)
                        .background(Color.gray.opacity(0.3))
                        .foregroundColor(.black)
                        .cornerRadius(10)
                        .padding(.horizontal)
                        .focused($isDescriptionFocused) // Link focus to this TextEditor

                    Spacer(minLength: 100)

                    Button(action: saveGoal) {
                        Text("Save Goal")
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                    .padding(.bottom)
                }
                .padding(.top)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .navigationTitle(isNewGoal ? "Add Goal" : "Edit Goal")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Save Goal to Firestore
    private func saveGoal() {
        guard let user = authViewModel.user else { return }

        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)

        userRef.getDocument { document, error in
            if let document = document, document.exists {
                var goals = document.data()?["goals"] as? [[String: Any]] ?? []

                if !isNewGoal {
                    goals.removeAll { $0["id"] as? String == goal.id }
                }

                goals.append(goal.toDict())

                userRef.updateData([
                    "goals": goals
                ]) { error in
                    if let error = error {
                        print("Error saving goal: \(error.localizedDescription)")
                    } else {
                        print("Goal saved successfully!")
                        onSave()
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Preview
struct EditGoalView_Previews: PreviewProvider {
    static var previews: some View {
        EditGoalView(goal: Goal(id: "1", title: "Preview Title", description: "Preview Description", createdAt: Date()), isNewGoal: true, onSave: {})
            .environmentObject(AuthViewModel())
    }
}

