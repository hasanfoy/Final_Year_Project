//
//  WeightTrackingView.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import SwiftUI
import Charts
import FirebaseFirestore
import FirebaseAuth

// MARK: - Weight Tracking View
struct WeightTrackingView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var weightEntries: [WeightEntry] = []
    @State private var animateChart = false

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Weight Progress")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.white)

                if !weightEntries.isEmpty {
                    Chart {
                        ForEach(Array(weightEntries.enumerated()), id: \.element.id) { index, entry in
                            BarMark(
                                x: .value("Entry", index + 1),
                                y: .value("Weight", animateChart ? entry.weight : 0)
                            )
                            .foregroundStyle(
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.blue.opacity(0.8)]),
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .cornerRadius(5)
                        }
                    }
                    .chartXScale(domain: 1...weightEntries.count + 1)
                    .chartXAxis {
                        AxisMarks(values: .automatic(desiredCount: 5)) { value in
                            AxisGridLine()
                            AxisValueLabel {
                                if let intValue = value.as(Int.self) {
                                    Text("\(intValue)")
                                        .foregroundColor(.white)
                                }
                            }
                        }
                    }
                    .chartYAxis {
                        AxisMarks {
                            AxisGridLine()
                            AxisValueLabel()
                        }
                    }
                    .frame(height: 250)
                    .padding()
                    .onAppear {
                        withAnimation(.easeOut(duration: 1.5)) {
                            animateChart = true
                        }
                    }

                } else {
                    Text("No weight data yet.")
                        .foregroundColor(.gray)
                        .padding(.top, 100)
                }

                Divider()
                    .background(Color.white.opacity(0.3))
                    .padding(.horizontal)

                Text("History")
                    .font(.title3)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.top, 10)

                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(weightEntries.sorted(by: { $0.date > $1.date })) { entry in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("\(String(format: "%.1f", entry.weight)) kg")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                    Text(entry.date, style: .date)
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                }
                                Spacer()
                            }
                            .padding()
                            .background(Color.purple.opacity(0.2))
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .padding()
        }
        .onAppear {
            fetchWeightHistory()
        }
    }

    // MARK: - Fetch Weight History
    private func fetchWeightHistory() {
        guard let user = Auth.auth().currentUser else {
            print("No current Firebase user.")
            return
        }

        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)

        userRef.getDocument { document, error in
            if let document = document, document.exists {
                let data = document.data()
                if let weightHistory = data?["weightHistory"] as? [[String: Any]] {
                    self.weightEntries = weightHistory.compactMap { item in
                        guard let weight = item["weight"] as? Double,
                              let timestamp = item["date"] as? Timestamp else { return nil }
                        return WeightEntry(weight: weight, date: timestamp.dateValue())
                    }
                }
            } else {
                print("Error fetching weight history: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }
}

// MARK: - Preview
struct WeightTrackingView_Previews: PreviewProvider {
    static var previews: some View {
        WeightTrackingView()
            .environmentObject(AuthViewModel())
    }
}



