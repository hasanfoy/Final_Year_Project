//
//  navigaitonManager.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//

import Foundation
import SwiftUI
import CoreMotion
import FirebaseAuth
import FirebaseFirestore

class ExerciseViewModel: ObservableObject {
    // MARK: - User Settings
    @Published var selectedExercise: String = ""
    @Published var userWeight: Double = 0.0
    @Published var selectedOption: String = "Time"
    @Published var time: Int = 30
    @Published var distance: Double = 2.0

    // MARK: - Workout State
    @Published var elapsedTime: Int = 0
    @Published var walkedDistance: Double = 0.0
    @Published var caloriesBurned: Double = 0.0
    @Published var pace: Double = 0.0
    @Published var isRunning: Bool = false
    @Published var stepCount: Int = 0
    @Published var showSummary: Bool = false
    @Published var isLoadingWeight: Bool = true
    @Published var isWorkoutSaved = false

    private var timer: Timer?
    private let pedometer = CMPedometer()

    // MARK: - New State for Resume Support
    private var distanceBeforePause: Double = 0.0 // stores total distance before pause
    private var pedometerStartDate: Date?         // stores time when pedometer starts

    init() {
        fetchUserWeight()
    }

    func fetchUserWeight() {
        isLoadingWeight = true

        guard let user = Auth.auth().currentUser else {
            print("No authenticated user.")
            isLoadingWeight = false
            return
        }

        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)

        userRef.getDocument { document, error in
            DispatchQueue.main.async {
                self.isLoadingWeight = false

                if let document = document, document.exists {
                    let data = document.data()
                    if let latestWeight = data?["currentWeight"] as? Double ?? data?["weight"] as? Double {
                        self.userWeight = latestWeight
                        print("Fetched user weight: \(self.userWeight) kg")
                    }
                } else {
                    print("Error fetching user weight: \(error?.localizedDescription ?? "Unknown error")")
                }
            }
        }
    }

    func prepareForWorkout() {
        elapsedTime = 0
        walkedDistance = 0.0
        caloriesBurned = 0.0
        pace = 0.0
        isRunning = false
        stepCount = 0

        // Reset for resume support
        distanceBeforePause = 0.0
        pedometerStartDate = nil
    }

    func startWorkout() {
        guard !isRunning else { return }
        isRunning = true
        pedometerStartDate = Date() // store current start time

        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            DispatchQueue.main.async {
                self.elapsedTime += 1
                self.updatePace()
                self.calculateCalories()
                self.checkWorkoutProgress()
            }
        }

        startPedometer(from: pedometerStartDate!)
    }

    func pauseWorkout() {
        timer?.invalidate()
        isRunning = false
        pedometer.stopUpdates()

        // Save partial distance during pause
        if let start = pedometerStartDate {
            pedometer.queryPedometerData(from: start, to: Date()) { data, _ in
                DispatchQueue.main.async {
                    if let data = data, let newDistance = data.distance {
                        self.distanceBeforePause += newDistance.doubleValue / 1000.0 // convert to km
                    }
                }
            }
        }
    }

    func resumeWorkout() {
        guard !isRunning else { return }
        isRunning = true
        pedometerStartDate = Date() // reset pedometer start time

        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            DispatchQueue.main.async {
                self.elapsedTime += 1
                self.updatePace()
                self.calculateCalories()
                self.checkWorkoutProgress()
            }
        }

        startPedometer(from: pedometerStartDate!)
    }

    func stopWorkout() {
        timer?.invalidate()
        pedometer.stopUpdates()
        isRunning = false
    }

    func endWorkout() {
        stopWorkout()
        showSummary = true
    }

    func checkWorkoutProgress() {
        if selectedOption == "Time" && elapsedTime >= (time * 60) {
            endWorkout()
        } else if selectedOption == "Distance" && walkedDistance >= distance {
            endWorkout()
        }
    }

    // MARK: - Updated to support resume logic
    private func startPedometer(from startDate: Date) {
        pedometer.startUpdates(from: startDate) { data, _ in
            DispatchQueue.main.async {
                guard let data = data else { return }
                self.stepCount = data.numberOfSteps.intValue

                if let pedometerDistance = data.distance {
                    let newDistance = pedometerDistance.doubleValue / 1000.0 // convert m to km
                    self.walkedDistance = self.distanceBeforePause + newDistance
                    self.updatePace()
                    self.calculateCalories()
                }
            }
        }
    }

    func calculateCalories() {
        guard isRunning else { return }

        switch selectedExercise {
        case "Walking":
            caloriesBurned = userWeight * walkedDistance * 0.57
        case "Running":
            caloriesBurned = userWeight * walkedDistance * 0.9
        case "Hiking":
            caloriesBurned = userWeight * walkedDistance * 0.62
        case "Swimming":
            caloriesBurned = Double(elapsedTime) / 60.0 * 10
        case "Push ups":
            caloriesBurned = Double(elapsedTime) / 60.0 * 8
        default:
            caloriesBurned = 0
        }
    }

    func updatePace() {
        if walkedDistance > 0 && elapsedTime > 0 && isRunning {
            pace = (Double(elapsedTime) / 60.0) / walkedDistance
        } else {
            pace = 0.0
        }
    }

    // MARK: - Formatters and Helpers
    var totalPace: Double {
        walkedDistance > 0 && elapsedTime > 0 ? (Double(elapsedTime) / 60.0) / walkedDistance : 0.0
    }

    var formattedElapsedTime: String {
        String(format: "%02d:%02d", elapsedTime / 60, elapsedTime % 60)
    }

    var formattedTimeLeft: String {
        let remaining = max((time * 60) - elapsedTime, 0)
        return String(format: "%02d:%02d", remaining / 60, remaining % 60)
    }

    var elapsedDistanceFormatted: String {
        String(format: "%.2f km", walkedDistance)
    }

    var progress: Double {
        selectedOption == "Time"
            ? Double(elapsedTime) / Double(time * 60)
            : walkedDistance / distance
    }

    // MARK: Save Workout History to Firestore
    func saveWorkoutHistory(completion: @escaping (Bool) -> Void) {
        // Check for internet first
        guard NetworkMonitor().isConnected else {
            print("No internet connection. Cannot save.")
            completion(false)
            return
        }

        guard let user = Auth.auth().currentUser else {
            print("No authenticated user.")
            completion(false)
            return
        }

        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)

        let workoutEntry: [String: Any] = [
            "date": Date(),
            "exerciseType": selectedExercise,
            "totalTime": formattedElapsedTime,
            "distance": walkedDistance,
            "calories": caloriesBurned,
            "pace": totalPace
        ]

        db.runTransaction({ transaction, errorPointer in
            let snapshot: DocumentSnapshot
            do {
                snapshot = try transaction.getDocument(userRef)
            } catch let fetchError {
                print("Fetch error: \(fetchError.localizedDescription)")
                return nil
            }

            var currentHistory = snapshot.data()?["workoutHistory"] as? [[String: Any]] ?? []

            // Prevent duplicate (same type + time)
            let alreadyExists = currentHistory.contains(where: { workout in
                guard let type = workout["exerciseType"] as? String,
                      let time = workout["totalTime"] as? String else { return false }
                return type == self.selectedExercise && time == self.formattedElapsedTime
            })

            if alreadyExists {
                print("Duplicate workout found. Skipping save.")
                return nil
            }

            currentHistory.append(workoutEntry)
            transaction.updateData(["workoutHistory": currentHistory], forDocument: userRef)

            return nil
        }) { (_, error) in
            if let error = error {
                print("Transaction failed: \(error.localizedDescription)")
                completion(false)
            } else {
                print("Workout saved successfully.")
                completion(true)
            }
        }
    }

}
