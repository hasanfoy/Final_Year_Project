//
//  WorkOutView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//
import SwiftUI

struct WorkoutView: View {
    @StateObject var exerciseVM = ExerciseViewModel()
    @State private var navPath = NavigationPath()

    var body: some View {
        NavigationStack(path: $navPath) {
            ZStack {
                Color(hex: "060218").ignoresSafeArea()

                VStack(alignment: .leading, spacing: 20) {
                    Text("It's time to do some\nworkout now....")
                        .font(.title3)
                        .foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.top, 20)

                    ScrollView {
                        VStack(spacing: 15) {
                            ForEach(["Walking", "Hiking", "Running", "Swimming", "Push ups"], id: \.self) { title in
                                Button {
                                    exerciseVM.selectedExercise = title
                                    navPath.append("ExerciseDetail")
                                } label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.black.opacity(0.5)]), startPoint: .leading, endPoint: .trailing))
                                            .frame(height: 80)

                                        HStack {
                                            VStack(alignment: .leading, spacing: 5) {
                                                Text(title)
                                                    .font(.headline)
                                                    .bold()
                                                    .foregroundColor(.white)
                                                Text("Tap to Start")
                                                    .font(.caption)
                                                    .foregroundColor(.gray)
                                            }
                                            Spacer()
                                            Image(systemName: "chevron.right")
                                                .foregroundColor(.white)
                                        }
                                        .padding()
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                }
            }
            .navigationDestination(for: String.self) { destination in
                switch destination {
                case "ExerciseDetail":
                    ExerciseDetailView(navPath: $navPath).environmentObject(exerciseVM)
                case "ExerciseTracking":
                    ExerciseTrackingView(navPath: $navPath).environmentObject(exerciseVM)
                case "WorkoutSummary":
                    WorkoutSummaryView(navPath: $navPath).environmentObject(exerciseVM)
                default:
                    EmptyView()
                }
            }
        }
    }
}
struct WorkoutView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutView()
    }
}
