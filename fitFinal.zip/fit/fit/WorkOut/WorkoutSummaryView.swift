//
//  WorkoutSummaryView.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//
import SwiftUI

struct WorkoutSummaryView: View {
    @EnvironmentObject var exerciseVM: ExerciseViewModel
    @StateObject private var networkMonitor = NetworkMonitor()
    @Binding var navPath: NavigationPath

    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var hasSavedWorkout = false

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Workout Summary")
                    .font(.title2)
                    .foregroundColor(.white)

                VStack(spacing: 15) {
                    StatBox(icon: "clock.fill", title: "Total Time", value: exerciseVM.formattedElapsedTime)
                    StatBox(icon: "map.fill", title: "Total Distance", value: exerciseVM.elapsedDistanceFormatted)
                    StatBox(icon: "flame.fill", title: "Calories", value: String(format: "%.1f kcal", exerciseVM.caloriesBurned))
                    StatBox(icon: "speedometer", title: "Avg Pace", value: String(format: "%.2f min/km", exerciseVM.totalPace))
                }
                .padding(.horizontal)

                HStack(spacing: 20) {
                    if networkMonitor.isConnected {
                        Button {
                            saveWorkout()
                        } label: {
                            HStack {
                                Image(systemName: "square.and.arrow.down")
                                Text(hasSavedWorkout ? "Saved" : "Save")
                            }
                            .foregroundColor(.white)
                            .padding()
                            .background(hasSavedWorkout ? Color.gray : Color.green)
                            .cornerRadius(10)
                        }
                        .disabled(hasSavedWorkout)
                    }

                    Button("Done") {
                        navPath.removeLast(navPath.count)
                    }
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
                }
                .padding(.top, 20)
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Workout Save Status"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
        .navigationBarBackButtonHidden(true)
    }

    private func saveWorkout() {
        guard !hasSavedWorkout else {
            alertMessage = " Workout already saved!"
            showAlert = true
            return
        }

        exerciseVM.saveWorkoutHistory { success in
            if success {
                alertMessage = " Workout saved successfully!"
                hasSavedWorkout = true
            } else {
                alertMessage = " Workout could not be saved. Please check your internet."
            }
            showAlert = true
        }
    }
}
struct WorkoutSummaryView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutSummaryView(navPath: .constant(NavigationPath()))
            .environmentObject(ExerciseViewModel())
    }
}












