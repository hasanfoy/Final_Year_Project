//
//  ExerciseDetailView.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//
import SwiftUI

struct ExerciseDetailView: View {
    @EnvironmentObject var exerciseVM: ExerciseViewModel
    @Binding var navPath: NavigationPath
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(spacing: 20) {
                // MARK: - Top Bar
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "arrow.left")
                            .foregroundColor(.white)
                            .padding()
                    }
                    Spacer()
                }

                Text("Choose Workout Mode")
                    .font(.title2)
                    .foregroundColor(.white)

                // MARK: - Mode Picker
                Picker("Mode", selection: $exerciseVM.selectedOption) {
                    Text("Time").tag("Time")
                    Text("Distance").tag("Distance")
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                // MARK: - Input Field
                if exerciseVM.selectedOption == "Time" {
                    VStack {
                        Text("Set Time (minutes)").foregroundColor(.white)
                        TextField("Enter time", value: $exerciseVM.time, formatter: NumberFormatter())
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .padding()
                    }
                } else {
                    VStack {
                        Text("Set Distance (km)").foregroundColor(.white)
                        TextField("Enter distance", value: $exerciseVM.distance, formatter: NumberFormatter())
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                            .padding()
                    }
                }

                // MARK: - Start Workout Button
                Button {
                    exerciseVM.prepareForWorkout()
                    navPath.append("ExerciseTracking")
                } label: {
                    Text("Start Workout")
                        .bold()
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding(.top, 20)

                Spacer()
            }
            .padding()
        }
        .navigationBarBackButtonHidden(true)
    }
}

// MARK: - Preview
struct ExerciseDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ExerciseDetailView(navPath: .constant(NavigationPath()))
            .environmentObject(ExerciseViewModel())
    }
}





