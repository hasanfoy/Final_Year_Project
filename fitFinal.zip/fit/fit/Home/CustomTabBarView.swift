//
//  CustomTabBarView.swift
//  fit
//
//  Created by Foysal Hasan on 09/02/2025.
//
import SwiftUI

struct CustomTabBarView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
                .tag(0)
            WorkoutView()
                .tabItem {
                    Image(systemName: "figure.walk")
                    Text("Activity")
                }
                .tag(1)
            HistoryView()
                .tabItem {
                    Image(systemName: "calendar")
                    Text("History")
                }
                .tag(2)
            EssentialsView()
                .tabItem {
                    Image(systemName: "plus.circle.fill")
                    Text("Essential")
                }
                .tag(3)
            UserProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
                .tag(4)
        }
        .accentColor(.white)
        .onChange(of: authViewModel.isLoggedIn) { isLoggedIn in
            if !isLoggedIn {
                // Optionally reset tab index
                selectedTab = 0
            }
        }
    }
}


//MARK: Preview
struct CustomTabBarView_Previews: PreviewProvider {
    static var previews: some View {
        CustomTabBarView()
            .environmentObject(AuthViewModel())
    }
}

