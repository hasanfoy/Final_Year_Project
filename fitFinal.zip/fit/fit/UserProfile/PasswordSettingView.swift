//
//  PasswordSettingView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//
import SwiftUI
import FirebaseAuth

// MARK: - Password Settings View
struct PasswordSettingsView: View {
    @State private var currentPassword: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var isUpdating = false
    
    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("Change Password")
                    .font(.title2)
                    .foregroundColor(.white)
                    .bold()
                    .padding(.top, 20)
                
                // MARK: - Current Password Field
                VStack(alignment: .leading, spacing: 5) {
                    Text("Current Password")
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    SecureField("Enter current password", text: $currentPassword)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal, 10)
                        .frame(height: 40)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                        .onChange(of: currentPassword) { _ in showError = false }
                }
                .padding(.horizontal, 20)
                
                // MARK: - New Password Field
                VStack(alignment: .leading, spacing: 5) {
                    Text("New Password")
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    SecureField("Enter new password", text: $newPassword)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal, 10)
                        .frame(height: 40)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                        .onChange(of: newPassword) { _ in showError = false }
                }
                .padding(.horizontal, 20)
                
                // MARK: - Confirm Password Field
                VStack(alignment: .leading, spacing: 5) {
                    Text("Confirm New Password")
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    SecureField("Confirm new password", text: $confirmPassword)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal, 10)
                        .frame(height: 40)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                        .onChange(of: confirmPassword) { _ in showError = false }
                }
                .padding(.horizontal, 20)
                
                if showError {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                        .padding(.horizontal, 20)
                }
                
                // MARK: - Change Password Button
                Button(action: {
                    updatePassword()
                }) {
                    Text(isUpdating ? "Updating..." : "Change Password")
                        .foregroundColor(.white)
                        .frame(width: 250, height: 40)
                        .background(newPassword.isEmpty || confirmPassword.isEmpty ? Color.gray : Color.blue)
                        .cornerRadius(10)
                }
                .disabled(newPassword.isEmpty || confirmPassword.isEmpty || isUpdating)
                
                Spacer()
            }
        }
    }
    
    // MARK: - Update Password Logic
    private func updatePassword() {
        guard let user = Auth.auth().currentUser else { return }
        
        if newPassword != confirmPassword {
            showError = true
            errorMessage = "Passwords do not match!"
            return
        }
        
        isUpdating = true
        let credential = EmailAuthProvider.credential(withEmail: user.email!, password: currentPassword)
        user.reauthenticate(with: credential) { _, error in
            if let error = error {
                showError = true
                errorMessage = "Re-authentication failed: \(error.localizedDescription)"
                isUpdating = false
            } else {
                user.updatePassword(to: newPassword) { error in
                    DispatchQueue.main.async {
                        isUpdating = false
                        if let error = error {
                            showError = true
                            errorMessage = "Failed to update password: \(error.localizedDescription)"
                        } else {
                            errorMessage = "Password updated successfully!"
                            showError = true
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Preview
struct PasswordSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        PasswordSettingsView()
    }
}

