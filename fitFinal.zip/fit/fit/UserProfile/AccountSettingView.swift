//
//  AccountSettingView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
import SwiftUI
import FirebaseAuth
import FirebaseFirestore

// MARK: - Account Settings View
struct AccountSettingsView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var newName: String = ""
    @State private var newEmail: String = ""
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var isUpdating = false
    
    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("Account Settings")
                    .font(.title2)
                    .foregroundColor(.white)
                    .bold()
                    .padding(.top, 20)
                
                // MARK: - Profile Picture Placeholder
                Button(action: {
                    print("Profile picture update - Dummy")
                }) {
                    Circle()
                        .fill(Color.white.opacity(0.2))
                        .frame(width: 100, height: 100)
                        .overlay(
                            Image(systemName: "camera.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)
                        )
                }
                
                // MARK: - Name Input
                VStack(alignment: .leading, spacing: 5) {
                    Text("Change Your Name")
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    TextField("Enter your name", text: $newName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal, 10)
                        .frame(height: 40)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                        .onChange(of: newName) { _ in showError = false }
                    
                    if showError {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.caption)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(.horizontal, 20)
                
                // MARK: - Save Name Button
                Button(action: {
                    updateUserName()
                }) {
                    Text(isUpdating ? "Updating..." : "Save Name")
                        .foregroundColor(.white)
                        .frame(width: 200, height: 40)
                        .background(newName.isEmpty ? Color.gray : Color.green)
                        .cornerRadius(10)
                }
                .disabled(newName.isEmpty || isUpdating)
                
                // MARK: - Email Input
                VStack(alignment: .leading, spacing: 5) {
                    Text("Change Your Email")
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    TextField("Enter your email", text: $newEmail)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal, 10)
                        .frame(height: 40)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                        .onChange(of: newEmail) { _ in showError = false }
                    
                    if showError {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.caption)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(.horizontal, 20)
                
                // MARK: - Update Email (Dummy)
                Button(action: {
                    print("Email update - Dummy")
                }) {
                    VStack {
                        Text("Update Email")
                        Text("(Coming Soon)")
                    }
                    .foregroundColor(.white)
                    .frame(width: 200, height: 60)
                    .background(newEmail.isEmpty ? Color.gray : Color.green)
                    .cornerRadius(10)
                }
                .padding(.top, 10)
                
                Spacer()
            }
        }
        .onAppear {
            newName = authViewModel.user?.displayName ?? ""
        }
    }
    
    // MARK: - Update Name Logic
    private func updateUserName() {
        guard let user = Auth.auth().currentUser else { return }
        let db = Firestore.firestore()
        
        if newName.isEmpty {
            showError = true
            errorMessage = "Name cannot be empty."
            return
        }
        
        isUpdating = true
        
        let changeRequest = user.createProfileChangeRequest()
        changeRequest.displayName = newName
        changeRequest.commitChanges { error in
            DispatchQueue.main.async {
                if let error = error {
                    self.showError = true
                    self.errorMessage = "Failed to update name: \(error.localizedDescription)"
                    self.isUpdating = false
                } else {
                    db.collection("users").document(user.uid).setData(["fullName": self.newName], merge: true) { error in
                        DispatchQueue.main.async {
                            self.isUpdating = false
                            if let error = error {
                                self.showError = true
                                self.errorMessage = "Firestore Update Failed: \(error.localizedDescription)"
                            } else {
                                self.authViewModel.fetchLatestUserInfo()
                            }
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Preview
struct AccountSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        AccountSettingsView()
            .environmentObject(AuthViewModel())
    }
}


