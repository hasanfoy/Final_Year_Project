//
//  WeatherViewModel.swift
//  fit
//
//  Created by Foysal Hasan on 09/02/2025.
//
import Foundation
import Combine

// MARK: - Weather ViewModel
class WeatherViewModel: ObservableObject {
    @Published var weather: Weather?
    @Published var hasWeatherAlert = false

    init() {
        fetchWeather()
    }
    
    private let apiKey = "90ae719116c1ea6ee90b31ff0ce276ab"
    private let city = "London"
    
    func fetchWeather() {
        let urlString = "https://api.openweathermap.org/data/2.5/weather?q=\(city)&appid=\(apiKey)&units=metric"
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Weather API Error:", error.localizedDescription)
                return
            }
            guard let data = data else { return }
            do {
                let decodedData = try JSONDecoder().decode(OpenWeatherResponse.self, from: data)
                DispatchQueue.main.async {
                    self.weather = Weather(from: decodedData)
                    print("Weather fetched successfully:", self.weather ?? "No weather data")
                }
            } catch {
                print("Failed to decode weather data:", error)
            }
        }.resume()
    }
}

// MARK: - Weather Model
struct Weather {
    let city: String
    let temperature: String
    let feelsLike: String
    let condition: String
    let icon: String
    let date: Date
    let dateString: String
    let dayString: String

    init(from response: OpenWeatherResponse) {
        self.city = response.name
        self.temperature = String(format: "%.1f", response.main.temp)
        self.feelsLike = String(format: "%.1f", response.main.feels_like)
        self.condition = response.weather.first?.description.capitalized ?? "Unknown"
        self.icon = WeatherIconMapper.map(response.weather.first?.icon ?? "")
        self.date = Date()

        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MMM-yy"
        self.dateString = formatter.string(from: date)

        formatter.dateFormat = "EEEE"
        self.dayString = formatter.string(from: date)
    }
}

// MARK: - OpenWeather API Response Models
struct OpenWeatherResponse: Codable {
    let name: String
    let main: Main
    let weather: [WeatherDetails]
}

struct Main: Codable {
    let temp: Double
    let feels_like: Double
}

struct WeatherDetails: Codable {
    let description: String
    let icon: String
}

// MARK: - Weather Icon Mapper
struct WeatherIconMapper {
    static func map(_ iconCode: String) -> String {
        switch iconCode {
        case "01d": return "sun.max.fill"
        case "01n": return "moon.fill"
        case "02d", "02n": return "cloud.sun.fill"
        case "03d", "03n": return "cloud.fill"
        case "04d", "04n": return "smoke.fill"
        case "09d", "09n": return "cloud.rain.fill"
        case "10d", "10n": return "cloud.heavyrain.fill"
        case "11d", "11n": return "cloud.bolt.fill"
        case "13d", "13n": return "snow"
        default: return "questionmark"
        }
    }
}



