//
//  DetailedWeatherView.swift
//  fit
//
//  Created by Foysal Hasan on 12/02/2025.
//
import SwiftUI

// MARK: - Detailed Weather View
struct DetailedWeatherView: View {
    @ObservedObject var weatherViewModel: WeatherViewModel
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack {
                // Back Button
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "arrow.left")
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                    Spacer()
                }
                .padding(.horizontal)

                // Current Weather Data
                if let weather = weatherViewModel.weather {
                    VStack(spacing: 15) {
                        Text(weather.city)
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(.white)

                        Text(weather.dateString)
                            .font(.headline)
                            .foregroundColor(.white.opacity(0.8))

                        Image(systemName: weather.icon)
                            .font(.system(size: 80))
                            .foregroundColor(.white)

                        Text(weather.condition)
                            .font(.title3)
                            .italic()
                            .foregroundColor(.white)

                        Text("Feels like: \(weather.feelsLike)°C")
                            .font(.headline)
                            .foregroundColor(.white.opacity(0.9))

                        // Weather Data
                        VStack(spacing: 15) {
                            HStack {
                                WeatherDataRow(icon: "thermometer.high", label: "High:", value: "\(weather.temperature)°C")
                                Spacer()
                                WeatherDataRow(icon: "thermometer.low", label: "Low:", value: "\(weather.temperature)°C")
                            }
                            WeatherDataRow(icon: "wind", label: "Wind Speed:", value: "2.1 m/s")
                            WeatherDataRow(icon: "drop.fill", label: "Humidity:", value: "91%")
                            WeatherDataRow(icon: "gauge", label: "Pressure:", value: "1019 hPa")
                        }
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(12)
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal)
                    }
                    .padding(.top, 40)
                } else {
                    ProgressView("Loading Weather...")
                        .foregroundColor(.white)
                }

                Spacer()

                // 7-Day Forecast
                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(WeatherForecast.sampleData, id: \.day) { forecast in
                            ForecastCardView(forecast: forecast)
                        }
                    }
                    .padding(.horizontal)
                }
            }
        }
        .onAppear {
            weatherViewModel.fetchWeather()
        }
    }
}

// MARK: - Weather Data Row
struct WeatherDataRow: View {
    let icon: String
    let label: String
    let value: String

    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.white)
                .font(.title2)

            Text("\(label) \(value)")
                .font(.headline)
                .foregroundColor(.white)

            Spacer()
        }
        .padding(.horizontal)
    }
}

// MARK: - Forecast Data Model
struct WeatherForecast: Identifiable {
    let id = UUID()
    let day: String
    let icon: String
    let condition: String
    let highTemp: String
    let lowTemp: String

    static let sampleData: [WeatherForecast] = [
        WeatherForecast(day: "Monday", icon: "cloud.sun.fill", condition: "Partly Cloudy", highTemp: "15", lowTemp: "7"),
        WeatherForecast(day: "Tuesday", icon: "cloud.fill", condition: "Cloudy", highTemp: "13", lowTemp: "6"),
        WeatherForecast(day: "Wednesday", icon: "sun.max.fill", condition: "Sunny", highTemp: "18", lowTemp: "9"),
        WeatherForecast(day: "Thursday", icon: "cloud.bolt.fill", condition: "Stormy", highTemp: "12", lowTemp: "5"),
        WeatherForecast(day: "Friday", icon: "cloud.rain.fill", condition: "Rainy", highTemp: "11", lowTemp: "4"),
        WeatherForecast(day: "Saturday", icon: "snow", condition: "Snowy", highTemp: "0", lowTemp: "-5"),
        WeatherForecast(day: "Sunday", icon: "sun.max.fill", condition: "Clear", highTemp: "16", lowTemp: "8")
    ]
}

// MARK: - Forecast Card View
struct ForecastCardView: View {
    let forecast: WeatherForecast

    var body: some View {
        HStack {
            Text(forecast.day)
                .font(.headline)
                .foregroundColor(.white)

            Spacer()

            Image(systemName: forecast.icon)
                .font(.title)
                .foregroundColor(.white)

            Spacer()

            VStack(alignment: .leading) {
                Text(forecast.condition)
                    .font(.subheadline)
                    .italic()
                    .foregroundColor(.white)

                HStack {
                    Text("H: \(forecast.highTemp)°C")
                        .font(.subheadline)
                        .foregroundColor(.white)
                    Text("L: \(forecast.lowTemp)°C")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.8))
                }
            }
        }
        .frame(height: 60)
        .padding(.horizontal, 15)
        .background(Color.white.opacity(0.2))
        .cornerRadius(12)
    }
}







