//
//  HomeView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//

import SwiftUI
import FirebaseFirestore

// MARK: - Home View
struct HomeView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @ObservedObject var weatherViewModel = WeatherViewModel()

    @State private var showingDetailedWeather = false

    var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "Good Morning"
        case 12..<18: return "Good Afternoon"
        case 18..<22: return "Good Evening"
        default: return "Good Night"
        }
    }

    var body: some View {
        ZStack {
            Color(hex: "060218")
                .ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 25) {
                    
                    // Greeting with User's Name & Bell Icon
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("\(greeting),")
                                .font(.title2)
                                .foregroundColor(.white)

                            Text(authViewModel.user?.displayName ?? authViewModel.fetchedUserName ?? "User")
                                .font(.largeTitle)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        Spacer()
                        
                        Image(systemName: "bell")
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    .onAppear {
                        authViewModel.fetchLatestUserInfo()
                    }
                    
                    // Weather View
                    if let weather = weatherViewModel.weather {
                        WeatherCard(weather: weather)
                            .onTapGesture {
                                showingDetailedWeather = true
                            }
                            .fullScreenCover(isPresented: $showingDetailedWeather) {
                                DetailedWeatherView(weatherViewModel: weatherViewModel)
                            }
                    } else {
                        ProgressView("Fetching Weather...")
                            .foregroundColor(.white)
                            .padding()
                    }

                    // HealthKit Steps and Progress View
                    HealthKitView()
                        .padding(.horizontal)

                    // Suggested Activities
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Fitness Activities")
                            .font(.title3)
                            .bold()
                            .foregroundColor(.white)
                        
                        SuggestedActivityView()
                    }
                    .padding(.horizontal)
                    
                }
                .padding(.bottom, 20)
            }
        }
        .onAppear {
            weatherViewModel.fetchWeather()
        }
    }
}

// MARK: - Weather Card
struct WeatherCard: View {
    var weather: Weather

    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(Color.white.opacity(0.3))
            .frame(height: 120)
            .frame(maxWidth: .infinity)
            .overlay(
                HStack {
                    VStack(alignment: .leading) {
                        Text(weather.city)
                            .font(.headline)
                            .bold()
                            .foregroundColor(.black)

                        Text(weather.dateString)
                            .font(.caption)
                            .foregroundColor(.gray)

                        Text(weather.dayString)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }

                    Spacer()

                    VStack {
                        Text("\(weather.temperature)°")
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(.black)

                        Text("Real feel: \(weather.feelsLike)°C")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }

                    Spacer()

                    VStack {
                        Image(systemName: weather.icon)
                            .font(.largeTitle)
                            .foregroundColor(.black)

                        Text(weather.condition)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                .padding()
            )
            .padding(.horizontal)
    }
}

// MARK: - Suggested Activity Section
struct SuggestedActivityView: View {
    var body: some View {
        HStack(spacing: 15) {
            ActivityCard(title: "Out Door Walk", duration: "30 Min", calories: "203 cal", icon: "figure.walk")
            ActivityCard(title: "Swimming", duration: "15 Min", calories: "300 cal", icon: "figure.pool.swim")
        }
    }
}

// MARK: - Individual Activity Card
struct ActivityCard: View {
    var title: String
    var duration: String
    var calories: String
    var icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(.white)

            Text(duration)
                .font(.caption)
                .foregroundColor(.white)

            Text(calories)
                .font(.headline)
                .bold()
                .foregroundColor(.white)

            Text(title)
                .font(.caption)
                .foregroundColor(.white)
        }
        .padding()
        .frame(width: 150, height: 120)
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.purple.opacity(0.4)))
    }
}

// MARK: - Preview
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(AuthViewModel())
    }
}
