//
//  HealthKitManager.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//
import SwiftUI
import HealthKit
import FirebaseFirestore
import FirebaseAuth

// MARK: - HealthKit Manager
class HealthKitManager: ObservableObject {
    private var healthStore = HKHealthStore()
    private let db = Firestore.firestore()
    private let userDefaults = UserDefaults.standard

    @Published var moveProgress: Double = 0.0
    @Published var stepProgress: Double = 0.0
    @Published var distanceProgress: Double = 0.0
    @Published var activeHourProgress: Double = 0.0
    @Published var userWeight: Double = 70.0

    @Published var caloriesGoal: Double = 600
    @Published var stepsGoal: Double = 11000
    @Published var distanceGoal: Double = 6.0
    @Published var activeHourGoal: Double = 3

    init() {
        print("HealthKitManager initialized")
        requestAuthorization()
        fetchUserWeight()
        loadGoals()
    }

    // MARK: - Authorization
    func requestAuthorization() {
        let typesToRead: Set<HKSampleType> = [
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
            HKObjectType.quantityType(forIdentifier: .distanceWalkingRunning)!,
            HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!
        ]
        
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            if success {
                self.fetchActivityData()
            } else {
                print("HealthKit authorization failed: \(String(describing: error))")
            }
        }
    }

    // MARK: - User Info
    private func fetchUserWeight() {
        guard let user = Auth.auth().currentUser else { return }
        let userRef = db.collection("users").document(user.uid)
        
        userRef.getDocument { (document, error) in
            if let document = document, document.exists {
                if let weight = document.data()?["weight"] as? Double {
                    DispatchQueue.main.async {
                        self.userWeight = weight
                    }
                }
            }
        }
    }

    // MARK: - Sync Health Data
    func syncHealthData() {
        guard let user = Auth.auth().currentUser else {
            print("No user logged in, cannot sync.")
            return
        }

        let userRef = db.collection("users").document(user.uid)
        
        DispatchQueue.global(qos: .background).async {
            userRef.getDocument { document, error in
                if let document = document, document.exists {
                    let fetchedCalories = document.data()?["caloriesGoal"] as? Double ?? self.caloriesGoal
                    let fetchedSteps = document.data()?["stepsGoal"] as? Double ?? self.stepsGoal
                    let fetchedDistance = document.data()?["distanceGoal"] as? Double ?? self.distanceGoal
                    let fetchedActiveHours = document.data()?["activeHourGoal"] as? Double ?? self.activeHourGoal
                    
                    DispatchQueue.main.async {
                        self.caloriesGoal = fetchedCalories
                        self.stepsGoal = fetchedSteps
                        self.distanceGoal = fetchedDistance
                        self.activeHourGoal = fetchedActiveHours
                        self.saveToUserDefaults()
                        print("Sync successful! Goals updated from Firebase.")
                    }
                } else {
                    print("Sync failed! No data found in Firebase.")
                }
            }
        }
    }

    // MARK: - Goals
    private func loadGoals() {
        guard let user = Auth.auth().currentUser else {
            loadFromUserDefaults()
            return
        }

        let userRef = db.collection("users").document(user.uid)
        userRef.getDocument { document, _ in
            if let document = document, document.exists {
                DispatchQueue.main.async {
                    self.caloriesGoal = document.data()?["caloriesGoal"] as? Double ?? self.caloriesGoal
                    self.stepsGoal = document.data()?["stepsGoal"] as? Double ?? self.stepsGoal
                    self.distanceGoal = document.data()?["distanceGoal"] as? Double ?? self.distanceGoal
                    self.activeHourGoal = document.data()?["activeHourGoal"] as? Double ?? self.activeHourGoal
                    self.saveToUserDefaults()
                }
            } else {
                self.loadFromUserDefaults()
            }
        }
    }

    private func loadFromUserDefaults() {
        DispatchQueue.main.async {
            self.caloriesGoal = self.userDefaults.double(forKey: "caloriesGoal") == 0 ? 600 : self.userDefaults.double(forKey: "caloriesGoal")
            self.stepsGoal = self.userDefaults.double(forKey: "stepsGoal") == 0 ? 11000 : self.userDefaults.double(forKey: "stepsGoal")
            self.distanceGoal = self.userDefaults.double(forKey: "distanceGoal") == 0 ? 6.0 : self.userDefaults.double(forKey: "distanceGoal")
            self.activeHourGoal = self.userDefaults.double(forKey: "activeHourGoal") == 0 ? 3 : self.userDefaults.double(forKey: "activeHourGoal")
        }
    }

    private func saveGoals() {
        saveToUserDefaults()
        saveToFirestore()
    }

    private func saveToUserDefaults() {
        userDefaults.set(caloriesGoal, forKey: "caloriesGoal")
        userDefaults.set(stepsGoal, forKey: "stepsGoal")
        userDefaults.set(distanceGoal, forKey: "distanceGoal")
        userDefaults.set(activeHourGoal, forKey: "activeHourGoal")
    }
    
    private func saveToFirestore() {
        guard let user = Auth.auth().currentUser else { return }
        let userRef = db.collection("users").document(user.uid)
        
        let updatedGoals: [String: Any] = [
            "caloriesGoal": caloriesGoal,
            "stepsGoal": stepsGoal,
            "distanceGoal": distanceGoal,
            "activeHourGoal": activeHourGoal
        ]
        
        userRef.setData(updatedGoals, merge: true) { error in
            if let error = error {
                print("Error saving goals: \(error.localizedDescription)")
            } else {
                print("Goals successfully saved!")
            }
        }
    }

    func updateGoals(calories: Double, steps: Double, distance: Double, activeHours: Double) {
        DispatchQueue.main.async {
            self.caloriesGoal = calories
            self.stepsGoal = steps
            self.distanceGoal = distance
            self.activeHourGoal = activeHours
            self.saveGoals()
        }
    }

    // MARK: - Fetch Activity Data
    func fetchActivityData() {
        fetchStepCount()
        fetchDistance()
        fetchCalories()
        fetchActiveHours()
    }

    private func fetchStepCount() {
        let type = HKQuantityType.quantityType(forIdentifier: .stepCount)!
        let startDate = Calendar.current.startOfDay(for: Date())
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: Date(), options: .strictStartDate)

        let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, result, error in
            if let error = error {
                print("Error fetching step count: \(error.localizedDescription)")
                return
            }
            guard let result = result, let sum = result.sumQuantity() else { return }
            DispatchQueue.main.async {
                self.stepProgress = sum.doubleValue(for: HKUnit.count())
                self.calculateCalories()
            }
        }
        healthStore.execute(query)
    }

    private func fetchDistance() {
        let type = HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!
        let startDate = Calendar.current.startOfDay(for: Date())
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: Date(), options: .strictStartDate)

        let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, result, error in
            guard let result = result, let sum = result.sumQuantity() else { return }
            DispatchQueue.main.async {
                self.distanceProgress = sum.doubleValue(for: HKUnit.meterUnit(with: .kilo))
                self.calculateCalories()
            }
        }
        healthStore.execute(query)
    }

    private func fetchCalories() {
        self.calculateCalories()
    }

    private func fetchActiveHours() {
        let activeHours = stepProgress / 1000
        DispatchQueue.main.async {
            self.activeHourProgress = min(activeHours, self.activeHourGoal)
        }
    }
    
    private func calculateCalories() {
        let estimatedCalories = distanceProgress * (0.5 * userWeight)
        DispatchQueue.main.async {
            self.moveProgress = estimatedCalories
        }
    }
}







