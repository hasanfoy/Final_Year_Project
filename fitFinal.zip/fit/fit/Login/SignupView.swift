//
//  SignupView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//
import SwiftUI
import FirebaseAuth

// MARK: - SignUp View
struct SignUpView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var email = ""
    @State private var name = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var navigateToVerification = false

    var passwordsMatch: Bool {
        return !confirmPassword.isEmpty && password == confirmPassword
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "060218")
                    .ignoresSafeArea()

                VStack {
                    // Back Button
                    HStack {
                        Button(action: {
                            navigateToVerification = false
                        }) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.white)
                                .font(.title2)
                        }
                        Spacer()
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Spacer()

                    // Title
                    Text("Start your journey with")
                        .foregroundColor(.white)
                        .font(.headline)

                    Text("FitBit")
                        .foregroundColor(.white)
                        .font(.title)
                        .bold()
                        .padding(.bottom, 40)

                    // Input Fields
                    VStack(alignment: .leading, spacing: 20) {
                        HStack {
                            Text("Name:")
                                .foregroundColor(.white)
                                .font(.headline)
                            TextField("Enter your name", text: $name)
                                .foregroundColor(.white)
                                .textFieldStyle(PlainTextFieldStyle())
                        }
                        .padding(.vertical, 10)
                        .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)

                        HStack {
                            Text("Email:")
                                .foregroundColor(.white)
                                .font(.headline)
                            TextField("email@example.com", text: $email)
                                .foregroundColor(.white)
                                .textFieldStyle(PlainTextFieldStyle())
                                .keyboardType(.emailAddress)
                        }
                        .padding(.vertical, 10)
                        .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)

                        HStack {
                            Text("Password:")
                                .foregroundColor(.white)
                                .font(.headline)
                            SecureField("Enter password", text: $password)
                                .foregroundColor(.white)
                                .textFieldStyle(PlainTextFieldStyle())
                        }
                        .padding(.vertical, 10)
                        .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)

                        HStack {
                            Text("Confirm Password:")
                                .foregroundColor(.white)
                                .font(.headline)
                            SecureField("Re-enter password", text: $confirmPassword)
                                .foregroundColor(.white)
                                .textFieldStyle(PlainTextFieldStyle())

                            if !confirmPassword.isEmpty {
                                Image(systemName: passwordsMatch ? "checkmark.circle.fill" : "xmark.circle.fill")
                                    .foregroundColor(passwordsMatch ? .green : .red)
                            }
                        }
                        .padding(.vertical, 10)
                        .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)
                    }
                    .padding(.horizontal, 30)

                    Spacer()

                    // Sign Up Button
                    Button(action: {
                        handleSignUp()
                    }) {
                        Text("Sign Up")
                            .foregroundColor(.white)
                            .frame(width: 300)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(25)
                    }
                    .padding(.bottom, 40)
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Sign Up"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                    }
                }
            }
            // Navigate to VerificationView after signing up
            .navigationDestination(isPresented: $navigateToVerification) {
                VerificationView(email: email)
            }
        }
    }

    // MARK: - Handle Sign Up
    private func handleSignUp() {
        guard passwordsMatch else {
            alertMessage = "Passwords do not match!"
            showAlert = true
            return
        }

        print("DEBUG: Name entered during signup: \(name)")

        authViewModel.signUp(email: email, password: password, name: name) { success, message in
            DispatchQueue.main.async {
                if success {
                    print("DEBUG: Navigating to verification page.")
                    authViewModel.navigateToVerification = true
                    navigateToVerification = true
                } else {
                    alertMessage = message
                    showAlert = true
                }
            }
        }
    }
}

// MARK: - Preview
struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
            .environmentObject(AuthViewModel())
    }
}
