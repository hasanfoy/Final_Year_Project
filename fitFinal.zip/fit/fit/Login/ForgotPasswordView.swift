//
//  ForgotPasswordView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//
import SwiftUI

// MARK: - Forgot Password View
struct ForgotPasswordView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var email: String = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "060218")
                    .ignoresSafeArea()

                VStack {

                    Spacer() // Pushes content to center

                    // Title
                    Text("Reset Password")
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.bottom, 5)

                    Text("Enter your email to receive a password reset link.")
                        .foregroundColor(.white.opacity(0.7))
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                        .padding(.bottom, 40)

                    // Email Input Field (Centered)
                    HStack {
                        Text("Email:")
                            .foregroundColor(.white)
                            .font(.headline)

                        TextField("email@example.com", text: $email)
                            .foregroundColor(.white)
                            .textFieldStyle(PlainTextFieldStyle())
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                    }
                    .padding(.vertical, 10)
                    .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)
                    .frame(maxWidth: 300)

                    // Reset Password Button
                    Button(action: {
                        authViewModel.resetPassword(email: email) { success, message in
                            self.alertMessage = message
                            self.showAlert = true
                        }
                    }) {
                        Text("Send Reset Link")
                            .foregroundColor(.white)
                            .frame(width: 300)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(25)
                    }
                    .padding(.top, 20)
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Password Reset"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                    }

                    Spacer()
                }
            }
        }
    }
}

// MARK: - Preview
struct ForgotPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ForgotPasswordView()
            .environmentObject(AuthViewModel())
    }
}
