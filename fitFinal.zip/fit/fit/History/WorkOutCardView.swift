//
//  Untitled.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import SwiftUI

//MARK: Workout Plan Card
struct WorkoutPlanCard: View {
    var title: String
    var duration: String
    var date: Date

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .foregroundColor(.white)

            HStack {
                Image(systemName: "clock")
                    .foregroundColor(.yellow)
                Text("Duration: \(duration)")
                    .foregroundColor(.gray)
                    .font(.subheadline)
            }

            HStack {
                Image(systemName: "calendar")
                    .foregroundColor(.purple)
                Text(date.formatted(date: .abbreviated, time: .shortened))
                    .foregroundColor(.gray)
                    .font(.subheadline)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.purple.opacity(0.6), Color.black.opacity(0.9)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.purple.opacity(0.6), lineWidth: 1)
        )
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.4), radius: 10, x: 0, y: 4)
        .padding(.horizontal)
    }
}



//MARK: Workout Detail Popup
struct WorkoutDetailPopup: View {
    var workout: WorkoutHistory
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(spacing: 20) {
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.white)
                        .font(.headline)
                    }
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 10)

                Text(workout.exerciseType)
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.top, 10)

                StatBox(icon: "clock.fill", title: "Total Time", value: workout.totalTime)
                StatBox(icon: "map.fill", title: "Distance", value: "\(String(format: "%.2f", workout.distance)) km")
                StatBox(icon: "flame.fill", title: "Calories", value: "\(String(format: "%.0f", workout.calories)) kcal")
                StatBox(icon: "speedometer", title: "Avg Pace", value: "\(String(format: "%.2f", workout.pace)) min/km")

                Spacer()
            }
            .padding()
        }
    }
}
