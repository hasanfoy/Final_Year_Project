//
//  HistoryModel.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import Foundation
import FirebaseCore

struct WorkoutHistory: Identifiable {
    var id = UUID()
    var date: Date
    var exerciseType: String
    var totalTime: String
    var distance: Double
    var calories: Double
    var pace: Double
}
