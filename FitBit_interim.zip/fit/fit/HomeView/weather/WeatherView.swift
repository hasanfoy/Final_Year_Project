//
//  WeatherView.swift
//  fit
//
//  Created by Foysal Hasan on 09/02/2025.
//

import SwiftUI

struct WeatherView: View {
    @ObservedObject var weatherViewModel = WeatherViewModel()
    @State private var showingWeatherDetails = false // ✅ Controls weather details visibility

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            if let weather = weatherViewModel.weather {
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color.white.opacity(0.2))
                    .frame(width: 440, height: 120)
                    .overlay(
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(weather.city)
                                    .font(.headline)
                                    .bold()
                                    .foregroundColor(.white)

                                Text(weather.dateString)
                                    .font(.caption)
                                    .foregroundColor(.gray)

                                Text(weather.dayString)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }

                            Spacer()

                            VStack {
                                Text("\(weather.temperature)°")
                                    .font(.largeTitle)
                                    .bold()
                                    .foregroundColor(.white)

                                Text("Real feel: \(weather.feelsLike)°C")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }

                            Spacer()

                            VStack {
                                Image(systemName: weather.icon)
                                    .font(.largeTitle)
                                    .foregroundColor(.white)

                                Text(weather.condition)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                    )
            } else {
                ProgressView("Loading Weather...")
                    .foregroundColor(.white)
            }
        }
        .onAppear {
            weatherViewModel.fetchWeather()
        }
        .onTapGesture {
            showingWeatherDetails = true
        }
        .fullScreenCover(isPresented: $showingWeatherDetails) {
            DetailedWeatherView(weatherViewModel: weatherViewModel)
        }
    }
}




// **✅ Preview**
struct WeatherView_Previews: PreviewProvider {
    static var previews: some View {
        WeatherView()
    }
}


