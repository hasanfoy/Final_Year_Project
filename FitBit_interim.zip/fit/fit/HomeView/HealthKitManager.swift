//
//  HealthKitManager.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//
import SwiftUI
import HealthKit
import FirebaseFirestore
import FirebaseAuth

class HealthKitManager: ObservableObject {
    private var healthStore = HKHealthStore()
    private let db = Firestore.firestore()
    private let userDefaults = UserDefaults.standard

    @Published var moveProgress: Double = 0.0
    @Published var stepProgress: Double = 0.0
    @Published var distanceProgress: Double = 0.0
    @Published var standProgress: Double = 0.0
    @Published var userWeight: Double = 70.0
    
    @Published var caloriesGoal: Double = 600
    @Published var stepsGoal: Double = 11000
    @Published var distanceGoal: Double = 6.0
    @Published var standGoal: Double = 12

    init() {
        print("HealthKitManager initialized")
        requestAuthorization()
        fetchUserWeight()
        loadGoals()
    }

    // ✅ Fetch stored goals from Firestore OR fallback to UserDefaults
    private func loadGoals() {
        guard let user = Auth.auth().currentUser else {
            print("❌ No user logged in, using defaults")
            loadFromUserDefaults()
            return
        }
        
        let userRef = db.collection("users").document(user.uid)
        userRef.getDocument { document, error in
            if let document = document, document.exists {
                DispatchQueue.main.async {
                    self.caloriesGoal = document.data()?["caloriesGoal"] as? Double ?? self.caloriesGoal
                    self.stepsGoal = document.data()?["stepsGoal"] as? Double ?? self.stepsGoal
                    self.distanceGoal = document.data()?["distanceGoal"] as? Double ?? self.distanceGoal
                    self.standGoal = document.data()?["standGoal"] as? Double ?? self.standGoal
                    self.saveToUserDefaults() // ✅ Sync Firestore → UserDefaults
                }
            } else {
                print("⚠️ Failed to fetch from Firestore, using local storage.")
                self.loadFromUserDefaults()
            }
        }
    }

    // ✅ Load goals from UserDefaults (if Firestore fails)
    private func loadFromUserDefaults() {
        DispatchQueue.main.async {
            self.caloriesGoal = self.userDefaults.double(forKey: "caloriesGoal") == 0 ? 600 : self.userDefaults.double(forKey: "caloriesGoal")
            self.stepsGoal = self.userDefaults.double(forKey: "stepsGoal") == 0 ? 11000 : self.userDefaults.double(forKey: "stepsGoal")
            self.distanceGoal = self.userDefaults.double(forKey: "distanceGoal") == 0 ? 6.0 : self.userDefaults.double(forKey: "distanceGoal")
            self.standGoal = self.userDefaults.double(forKey: "standGoal") == 0 ? 12 : self.userDefaults.double(forKey: "standGoal")
        }
    }

    // ✅ Save goals to both Firestore & UserDefaults
    private func saveGoals() {
        saveToUserDefaults()
        saveToFirestore()
    }

    private func saveToUserDefaults() {
        userDefaults.set(caloriesGoal, forKey: "caloriesGoal")
        userDefaults.set(stepsGoal, forKey: "stepsGoal")
        userDefaults.set(distanceGoal, forKey: "distanceGoal")
        userDefaults.set(standGoal, forKey: "standGoal")
    }

    private func saveToFirestore() {
        guard let user = Auth.auth().currentUser else { return }
        let userRef = db.collection("users").document(user.uid)
        
        let updatedGoals: [String: Any] = [
            "caloriesGoal": caloriesGoal,
            "stepsGoal": stepsGoal,
            "distanceGoal": distanceGoal,
            "standGoal": standGoal
        ]
        
        userRef.setData(updatedGoals, merge: true) { error in
            if let error = error {
                print("❌ Error saving goals: \(error.localizedDescription)")
            } else {
                print("✅ Goals successfully saved!")
            }
        }
    }

    // ✅ Update Goals & Save Immediately
    func updateGoals(calories: Double, steps: Double, distance: Double, stand: Double) {
        DispatchQueue.main.async {
            self.caloriesGoal = calories
            self.stepsGoal = steps
            self.distanceGoal = distance
            self.standGoal = stand
            self.saveGoals()
        }
    }

    func requestAuthorization() {
        let typesToRead: Set<HKSampleType> = [
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
            HKObjectType.quantityType(forIdentifier: .distanceWalkingRunning)!,
            HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!,
            HKObjectType.categoryType(forIdentifier: .appleStandHour)!
        ]
        
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            if success {
                self.checkAuthorizationStatus() // ✅ Check status after authorization
                self.fetchActivityData()
            } else {
                print("HealthKit authorization failed: \(String(describing: error))")
            }
        }
    }
    
    func fetchActivityData() {
        fetchStepCount()
        fetchDistance()
        fetchCalories()
        fetchStandHours()
    }
    
    private func fetchUserWeight() {
        guard let user = Auth.auth().currentUser else { return }
        let userRef = db.collection("users").document(user.uid)
        
        userRef.getDocument { (document, error) in
            if let document = document, document.exists {
                if let weight = document.data()?["weight"] as? Double {
                    DispatchQueue.main.async {
                        self.userWeight = weight
                    }
                }
            }
        }
    }
    
    private func fetchStepCount() {
        print("Fetching step count...")
        let type = HKQuantityType.quantityType(forIdentifier: .stepCount)!
        let startDate = Calendar.current.startOfDay(for: Date())
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: Date(), options: .strictStartDate)
        
        let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, result, error in
            if let error = error {
                print("Error fetching step count: \(error.localizedDescription)")
                return
            }
            
            guard let result = result, let sum = result.sumQuantity() else {
                print("No step count data available.")
                return
            }
            
            let stepCount = sum.doubleValue(for: HKUnit.count())
            print("Fetched step count: \(stepCount)")
            
            DispatchQueue.main.async {
                self.stepProgress = stepCount
                self.calculateCalories()
            }
        }
        
        healthStore.execute(query)
    }
    func checkAuthorizationStatus() {
        let typesToRead: Set<HKSampleType> = [
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
            HKObjectType.quantityType(forIdentifier: .distanceWalkingRunning)!,
            HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!,
            HKObjectType.categoryType(forIdentifier: .appleStandHour)!
        ]
        
        for type in typesToRead {
            let status = healthStore.authorizationStatus(for: type)
            print("Authorization status for \(type): \(status.rawValue)")
        }
    }



    
    private func fetchDistance() {
        let type = HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!
        let startDate = Calendar.current.startOfDay(for: Date())
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: Date(), options: .strictStartDate)
        
        let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, result, error in
            guard let result = result, let sum = result.sumQuantity() else { return }
            DispatchQueue.main.async {
                self.distanceProgress = sum.doubleValue(for: HKUnit.meterUnit(with: .kilo))
                self.calculateCalories()
            }
        }
        
        healthStore.execute(query)
    }
    
    private func fetchCalories() {
        self.calculateCalories()
    }
    
    private func fetchStandHours() {
        let type = HKCategoryType.categoryType(forIdentifier: .appleStandHour)!
        let startDate = Calendar.current.startOfDay(for: Date())
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: Date(), options: .strictStartDate)
        
        let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, results, error in
            guard let results = results as? [HKCategorySample] else { return }
            DispatchQueue.main.async {
                self.standProgress = Double(results.count)
            }
        }
        
        healthStore.execute(query)
    }
    
    private func calculateCalories() {
        let estimatedCalories = distanceProgress * (0.5 * userWeight)
        DispatchQueue.main.async {
            self.moveProgress = estimatedCalories
        }
    }
}



