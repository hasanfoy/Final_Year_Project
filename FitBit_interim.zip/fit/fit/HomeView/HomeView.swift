//
//  HomeView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//

import SwiftUI
import FirebaseFirestore

struct HomeView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @ObservedObject var weatherViewModel = WeatherViewModel()

    @State private var showingDetailedWeather = false // ✅ Controls Weather Details Visibility

    var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "Good Morning"
        case 12..<18: return "Good Afternoon"
        case 18..<22: return "Good Evening"
        default: return "Good Night"
        }
    }

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()

            VStack(alignment: .leading, spacing: 25) {
                // Greeting with User's Name & Bell Icon
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("\(greeting),")
                            .font(.title2)
                            .foregroundColor(.white)

                        Text(authViewModel.user?.displayName ?? authViewModel.fetchedUserName ?? "User")
                            .font(.title)
                            .bold()
                            .foregroundColor(.white)
                    }

                    Spacer()

                    Image(systemName: "bell")
                        .font(.title2)
                        .foregroundColor(.white)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .onAppear {
                    authViewModel.fetchLatestUserInfo()
                }

                // Weather View (Clickable for Details)
                if let weather = weatherViewModel.weather {
                    WeatherCard(weather: weather)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 20)
                        .onTapGesture { // ✅ Tap to Open
                            showingDetailedWeather = true
                        }
                        .fullScreenCover(isPresented: $showingDetailedWeather) { // ✅ Full-Screen Weather View
                            DetailedWeatherView(weatherViewModel: weatherViewModel)
                        }
                } else {
                    ProgressView("Fetching Weather...")
                        .foregroundColor(.white)
                        .padding()
                }

                // HealthKit View
                HealthKitView()

                // Suggested Activities
                VStack(alignment: .leading) {
                    Text("Fitness Activities")
                        .font(.title3)
                        .bold()
                        .foregroundColor(.white)

                    SuggestedActivityView()
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 50)
            }
        }
        .onAppear {
            weatherViewModel.fetchWeather()
            authViewModel.fetchLatestUserInfo()
        }
    }
}

// **✅ Weather Card Component**
struct WeatherCard: View {
    var weather: Weather

    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(Color.white.opacity(0.3))
            .frame(width: 400, height: 120)
            .overlay(
                HStack {
                    VStack(alignment: .leading) {
                        Text(weather.city)
                            .font(.headline)
                            .bold()
                            .foregroundColor(.black)

                        Text(weather.dateString)
                            .font(.caption)
                            .foregroundColor(.gray)

                        Text(weather.dayString)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }

                    Spacer()

                    VStack {
                        Text("\(weather.temperature)°")
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(.black)

                        Text("Real feel: \(weather.feelsLike)°C")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }

                    Spacer()

                    VStack {
                        Image(systemName: weather.icon)
                            .font(.largeTitle)
                            .foregroundColor(.black)

                        Text(weather.condition)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                .padding()
            )
    }
}




// **✅ Suggested Activities View**
struct SuggestedActivityView: View {
    var body: some View {
        HStack(spacing: 20) {
            ActivityCard(title: "Out Door Walk", duration: "30 Min", calories: "203 cal", icon: "figure.walk")
            ActivityCard(title: "Swimming", duration: "15 Min", calories: "300 cal", icon: "figure.pool.swim")
        }
    }
}

// **✅ Activity Card Component**
struct ActivityCard: View {
    var title: String
    var duration: String
    var calories: String
    var icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(.white)

            Text(duration)
                .font(.caption)
                .foregroundColor(.white)

            Text(calories)
                .font(.headline)
                .bold()
                .foregroundColor(.white)

            Text(title)
                .font(.caption)
                .foregroundColor(.white)
        }
        .padding()
        .frame(width: 140, height: 100)
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.purple.opacity(0.4)))
    }
}

// **✅ Preview**
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(AuthViewModel())
    }
}
