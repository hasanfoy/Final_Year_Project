//
//  UserProfileView.swift
//  fit
//
//  Created by Foysal Hasan on 09/02/2025.
//
import SwiftUI

struct UserProfileView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "060218").ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Text("Settings")
                        .font(.title2)
                        .foregroundColor(.white)
                        .bold()
                        .padding(.top, 20)
                    
                    VStack(spacing: 15) {
                        NavigationLink(destination: AccountSettingsView()) {
                            SettingRow(icon: "person.fill", title: "Account", iconColor: .green)
                        }
                        
                        NavigationLink(destination: PasswordSettingsView()) {
                            SettingRow(icon: "lock.fill", title: "Password", iconColor: .green)
                        }
                        
                        SettingRow(icon: "bell.fill", title: "Notifications", iconColor: .green)
                        
                        // ✅ Logout Button
                        Button(action: {
                            handleLogout()
                        }) {
                            HStack {
                                Circle()
                                    .fill(Color.red.opacity(0.2))
                                    .frame(width: 40, height: 40)
                                    .overlay(Image(systemName: "arrow.right.circle.fill")
                                        .foregroundColor(.red)
                                        .font(.title2))
                                
                                Text("Logout")
                                    .foregroundColor(.red)
                                    .font(.headline)
                                
                                Spacer()
                            }
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10)
                                .fill(Color.white.opacity(0.05)))
                        }
                    }
                    .padding(.horizontal, 20)
                    
                    Spacer()
                }
            }
        }
    }
    
    // ✅ Handles User Logout
    private func handleLogout() {
        authViewModel.logout()
        
        // ✅ Navigate to Login Screen or Update UI
        // You can use a navigation state variable or environment object to handle this.
        // For example:
        // authViewModel.isLoggedIn = false
    }
}

// ✅ **Reusable Setting Row Component**
struct SettingRow: View {
    var icon: String
    var title: String
    var iconColor: Color
    
    var body: some View {
        HStack {
            Circle()
                .fill(iconColor.opacity(0.2))
                .frame(width: 40, height: 40)
                .overlay(Image(systemName: icon)
                    .foregroundColor(iconColor)
                    .font(.title2))
            
            Text(title)
                .foregroundColor(.white)
                .font(.headline)
            
            Spacer()
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 10)
            .fill(Color.white.opacity(0.05)))
    }
}

// ✅ **Preview**
struct UserProfileView_Previews: PreviewProvider {
    static var previews: some View {
        UserProfileView()
            .environmentObject(AuthViewModel())
    }
}



