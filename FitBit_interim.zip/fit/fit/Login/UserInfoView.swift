//
//  UserInfoView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct UserInfoView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedGender: Gender = .male
    @State private var selectedAge: Int = 18
    @State private var height: String = ""
    @State private var weight: String = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var navigateToHome = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "060218")
                    .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: 15) {
                    
                    
                    
                    Spacer()
                    
                    // **Title**
                    Text("Tell us About Yourself")
                        .font(.title2)
                        .italic()
                        .foregroundColor(.white)
                        .padding(.bottom, 100)
                    
                    // **Gender Selection**
                    HStack {
                        Text("Gender:")
                            .foregroundColor(.white)
                            .font(.headline)
                        
                        Picker("Gender", selection: $selectedGender) {
                            ForEach(Gender.allCases, id: \.self) { gender in
                                Text(gender.rawValue).tag(gender)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .frame(width: 180)
                    }
                    .padding(.bottom, 10)
                    
                    // **Age Selection**
                    HStack {
                        Text("Age:")
                            .foregroundColor(.white)
                            .font(.headline)
                        
                        Picker("Age", selection: $selectedAge) {
                            ForEach(10...110, id: \.self) { age in
                                Text("\(age)").tag(age)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 100)
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(5)
                    }
                    .padding(.bottom, 10)
                    
                    // **Height Input**
                    HStack {
                        Text("Height (cm):")
                            .foregroundColor(.white)
                            .font(.headline)
                        
                        TextField("Enter height", text: $height)
                            .keyboardType(.decimalPad)
                            .foregroundColor(.white)
                            .padding(.vertical, 3)
                            .multilineTextAlignment(.trailing)
                    }
                    .padding(.bottom, 10)
                    .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)
                    .frame(maxWidth: 300)
                    
                    // **Weight Input**
                    HStack {
                        Text("Weight (kg):")
                            .foregroundColor(.white)
                            .font(.headline)
                        
                        TextField("Enter weight", text: $weight)
                            .keyboardType(.decimalPad)
                            .foregroundColor(.white)
                            .padding(.vertical, 3)
                            .multilineTextAlignment(.trailing)
                    }
                    .padding(.bottom, 10)
                    .overlay(Rectangle().frame(height: 1).foregroundColor(.white), alignment: .bottom)
                    .frame(maxWidth: 300)
                    
                    Spacer()
                    
                    // **Next Button**
                    HStack {
                        Spacer()
                        Button(action: saveUserInfo) {
                            HStack {
                                Text("Next")
                                    .foregroundColor(.white)
                                Image(systemName: "arrow.right")
                                    .foregroundColor(.white)
                            }
                            .padding()
                            .frame(width: 120)
                            .background(Color.blue)
                            .cornerRadius(20)
                        }
                    }
                    .padding(.trailing, 30)
                    .padding(.bottom, 20)
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                    }
                    
                }
                .padding(.horizontal, 30)
            }
            // ✅ Navigate to HomeView after saving (iOS 16+)
            .navigationDestination(isPresented: $navigateToHome) {
                CustomTabBarView()
            }
        }
    }
    
    private func saveUserInfo() {
        guard let user = Auth.auth().currentUser else {
            print("❌ User not authenticated.")
            alertMessage = "User not authenticated."
            showAlert = true
            return
        }
        
        let userId = user.uid
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(userId)
        
        // ✅ Fetch Existing Data Before Updating
        userRef.getDocument { (document, error) in
            var existingData = document?.data() ?? [:]
            
            // ✅ Keep the existing fullName if it exists
            let fullName = existingData["fullName"] as? String ?? user.displayName ?? ""
            
            print("🔥 DEBUG: Existing fullName before update: \(fullName)")
            
            let updatedUserData: [String: Any] = [
                "email": user.email ?? "",
                "fullName": fullName,  // ✅ Keep existing full name
                "gender": self.selectedGender.rawValue,
                "age": self.selectedAge,
                "height": Double(self.height) ?? 0,
                "weight": Double(self.weight) ?? 0
            ]
            
            userRef.setData(updatedUserData, merge: true) { error in
                if let error = error {
                    print("❌ Firestore Save Error: \(error.localizedDescription)")
                    self.alertMessage = "Failed to save data: \(error.localizedDescription)"
                    self.showAlert = true
                } else {
                    print("✅ Firestore update successful! Name: \(fullName)")
                    DispatchQueue.main.async {
                        self.navigateToHome = true
                    }
                }
            }
        }
    }
}
// **Gender Enum**
enum Gender: String, CaseIterable {
    case male = "Male"
    case female = "Female"
    case other = "Other"
}

// 🔥 Preview for UserInfoView
struct UserInfoView_Previews: PreviewProvider {
    static var previews: some View {
        UserInfoView()
            .environmentObject(AuthViewModel()) // Provide Environment Object
    }
}

