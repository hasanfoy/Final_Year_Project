//
//  EssentialView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//
import SwiftUI

struct EssentialsView: View {
    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea() // Background color
            
            VStack(alignment: .leading, spacing: 20) {
                Text("Essentials")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.horizontal, 20)
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    EssentialCard(icon: "flame.fill", title: "Body weight", description: "Input weight weekly to track progress.")
                    
                    EssentialCard(icon: "list.bullet.clipboard", title: "Goals", description: "List of all goals created.")
                    
                    EssentialCard(icon: "chart.bar.fill", title: "BMI Calculator", description: "Track your BMI record to measure your fitness.")
                }
                .padding(.horizontal, 20)
                
                Spacer()
            }
        }
    }
}

// **Reusable Card View**
struct EssentialCard: View {
    var icon: String
    var title: String
    var description: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Image(systemName: icon)
                .font(.largeTitle)
                .foregroundColor(.green)
            
            Text(title)
                .font(.headline)
                .bold()
                .foregroundColor(.white)
            
            Text(description)
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding()
        .frame(width: 160, height: 120)
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.purple.opacity(0.3)))
    }
}

// **Preview**
struct EssentialsView_Previews: PreviewProvider {
    static var previews: some View {
        EssentialsView()
    }
}

