//
//  WorkOutView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//

import SwiftUI

struct WorkoutView: View {
    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 20) {
                // **Motivational Message**
                Text("It's time to do some\nworkout now....")
                    .font(.title3)
                    .foregroundColor(.white)
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                
                // **Workout Plans List**
                ScrollView {
                    VStack(spacing: 15) {
                        WorkoutCard(title: "Walking", duration: "30 minutes")
                        WorkoutCard(title: "Hiking", duration: "30 minutes")
                        WorkoutCard(title: "Running", duration: "30 minutes")
                        WorkoutCard(title: "Swimming", duration: "30 minutes")
                        WorkoutCard(title: "Push ups", duration: "30 minutes", reps: "115", sets: "15", exercises: "5")
                    }
                }
                .padding(.horizontal, 20)
            }
        }
    }
}

// **Workout Card Component**
struct WorkoutCard: View {
    var title: String
    var duration: String
    var reps: String? = nil
    var sets: String? = nil
    var exercises: String? = nil
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .fill(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.black.opacity(0.5)]), startPoint: .leading, endPoint: .trailing))
                .frame(height: 80)
            
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text(title)
                        .font(.headline)
                        .bold()
                        .foregroundColor(.white)
                    
                    Text("Duration: \(duration)")
                        .font(.caption)
                        .foregroundColor(.gray)
                    
                    if let reps = reps, let sets = sets, let exercises = exercises {
                        Text("Reps: \(reps)  Sets: \(sets)  Exercise: \(exercises)")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                Spacer()
                
                Text("Edit plan")
                    .foregroundColor(.green)
                    .font(.caption)
                    .bold()
            }
            .padding()
        }
    }
}

// **Preview**
struct WorkoutView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutView()
    }
}
