//
//  navigaitonManager.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//

import Foundation
import SwiftUI
import CoreMotion

class ExerciseViewModel: ObservableObject {
    @Published var selectedExercise: String = ""
    @Published var userWeight: Double = 70.0 // Fetch from user data (during signup)
    @Published var selectedOption: String = "Time"
    @Published var time: Int = 30
    @Published var distance: Double = 2.0
    
    @Published var elapsedTime: Int = 0
    @Published var walkedDistance: Double = 0.0
    @Published var caloriesBurned: Double = 0.0
    @Published var pace: Double = 0.0
    @Published var isRunning: Bool = false
    @Published var stepCount: Int = 0
    @Published var showSummary: Bool = false
    
    private var timer: Timer?
    private let pedometer = CMPedometer()
    
    func prepareForWorkout() {
        elapsedTime = 0
        walkedDistance = 0.0
        caloriesBurned = 0.0
        pace = 0.0
        isRunning = false
        stepCount = 0
    }
    
    func startWorkout() {
        guard !isRunning else { return }
        isRunning = true
        
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            DispatchQueue.main.async {
                self.elapsedTime += 1
                self.updatePace()
                self.calculateCalories()
                self.checkWorkoutProgress()
            }
        }
        
        startPedometer()
    }
    
    func pauseWorkout() {
        timer?.invalidate()
        pedometer.stopUpdates()
        isRunning = false
    }
    
    func resumeWorkout() {
        startWorkout()
    }
    
    func stopWorkout() {
        timer?.invalidate()
        pedometer.stopUpdates()
        isRunning = false
    }
    
    func checkWorkoutProgress() {
        if selectedOption == "Time" && elapsedTime >= (time * 60) {
            endWorkout()
        } else if selectedOption == "Distance" && walkedDistance >= distance {
            endWorkout()
        }
    }
    
    func endWorkout() {
        stopWorkout()
        showSummary = true
    }
    
    func startPedometer() {
        if CMPedometer.isDistanceAvailable() {
            pedometer.startUpdates(from: Date()) { data, _ in
                DispatchQueue.main.async {
                    guard let data = data else { return }
                    self.stepCount = data.numberOfSteps.intValue
                    
                    if let pedometerDistance = data.distance {
                        self.walkedDistance = pedometerDistance.doubleValue / 1000.0
                        self.updatePace()
                        self.calculateCalories()
                    }
                }
            }
        }
    }

    
    func calculateCalories() {
        guard isRunning else { return }

        switch selectedExercise {
        case "Walking":
            caloriesBurned = userWeight * walkedDistance * 0.57 // Average 0.57 kcal per kg per km walking
        case "Running":
            caloriesBurned = userWeight * walkedDistance * 0.9 // Average ~0.9 kcal per kg per km running
        case "Hiking":
            caloriesBurned = userWeight * walkedDistance * 0.62
        case "Swimming":
            let minutesElapsed = Double(elapsedTime) / 60.0
            caloriesBurned = minutesElapsed * 10 // 10 kcal/min swimming
        case "Push ups":
            let minutesElapsed = Double(elapsedTime) / 60.0
            caloriesBurned = minutesElapsed * 8 // 8 kcal/min push-ups
        default:
            caloriesBurned = 0
        }
    }

    
    func updatePace() {
        if walkedDistance > 0 && elapsedTime > 0 && isRunning {
            // Live pace updates only while moving (min/km)
            pace = (Double(elapsedTime) / 60) / walkedDistance
        } else {
            pace = 0.0 // Reset to 0 if no movement
        }
    }

    var totalPace: Double {
        if walkedDistance > 0 && elapsedTime > 0 {
            return (Double(elapsedTime) / 60) / walkedDistance // (min/km)
        } else {
            return 0.0
        }
    }

    
    var formattedElapsedTime: String {
        String(format: "%02d:%02d", elapsedTime / 60, elapsedTime % 60)
    }
    
    var formattedTimeLeft: String {
        let remainingTime = max((time * 60) - elapsedTime, 0)
        return String(format: "%02d:%02d", remainingTime / 60, remainingTime % 60)
    }
    
    var elapsedDistanceFormatted: String {
        String(format: "%.2f km", walkedDistance)
    }
    
    var progress: Double {
        selectedOption == "Time"
            ? Double(elapsedTime) / Double(time * 60)
            : walkedDistance / distance
    }
}




