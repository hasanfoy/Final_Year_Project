//
//  WorkOutView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.
//
import SwiftUI

struct WorkoutView: View {
    @StateObject var exerciseVM = ExerciseViewModel()
    @StateObject var navigationManager = NavigationManager()
    
    var body: some View {
        NavigationStack(path: $navigationManager.path) {
            ZStack {
                Color(hex: "060218").ignoresSafeArea()
                VStack(alignment: .leading, spacing: 20) {
                    Text("It's time to do some\nworkout now....")
                        .font(.title3)
                        .foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.top, 20)
                    
                    ScrollView {
                        VStack(spacing: 15) {
                            WorkoutCard(title: "Walking", exerciseVM: exerciseVM)
                            WorkoutCard(title: "Hiking", exerciseVM: exerciseVM)
                            WorkoutCard(title: "Running", exerciseVM: exerciseVM)
                            WorkoutCard(title: "Swimming", exerciseVM: exerciseVM)
                            WorkoutCard(title: "Push ups", exerciseVM: exerciseVM)
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
            .navigationDestination(for: String.self) { value in
                if value.hasPrefix("ExerciseDetail") {
                    ExerciseDetailView()
                        .environmentObject(exerciseVM)
                        .environmentObject(navigationManager)
                } else if value.hasPrefix("ExerciseTracking") {
                    ExerciseTrackingView()
                        .environmentObject(exerciseVM)
                        .environmentObject(navigationManager)
                } else if value == "WorkoutSummary" {
                    WorkoutSummaryView()  // ✅ No need to pass exerciseVM
                        .environmentObject(exerciseVM)
                        .environmentObject(navigationManager)
                }
            }


        }
        .environmentObject(navigationManager)
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

struct WorkoutCard: View {
    var title: String
    @ObservedObject var exerciseVM: ExerciseViewModel
    @EnvironmentObject var navigationManager: NavigationManager  // ✅ Use EnvironmentObject
    
    var body: some View {
        Button(action: {
            exerciseVM.selectedExercise = title
            navigationManager.push("ExerciseDetail:\(title)")
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 15)
                    .fill(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.black.opacity(0.5)]), startPoint: .leading, endPoint: .trailing))
                    .frame(height: 80)
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(title)
                            .font(.headline)
                            .bold()
                            .foregroundColor(.white)
                        Text("Tap to Start")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.white)
                }
                .padding()
            }
        }
    }
}

// **Preview**
struct WorkoutView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutView()
            .environmentObject(NavigationManager())
    }
}




