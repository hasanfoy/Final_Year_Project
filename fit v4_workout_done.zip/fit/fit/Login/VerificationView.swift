//
//  VerificationView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//
import SwiftUI

struct VerificationView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    var email: String

    var body: some View {
        ZStack {
            Color(hex: "060218")
                .ignoresSafeArea()

            VStack {
                Text("Verify Your Email")
                    .font(.title)
                    .foregroundColor(.white)

                Text("Please check your email and click on the verification link.")
                    .padding()
                    .foregroundColor(.white)

                Text(email)
                    .foregroundColor(.gray)
                    .italic()

                Button("Check Verification") {
                    authViewModel.checkEmailVerification { success in
                        if success {
                            DispatchQueue.main.async {
                                authViewModel.navigateToUserInfo = true
                            }
                        }
                    }
                }
                .padding()
                .buttonStyle(.bordered)
                .foregroundStyle(.green)

                NavigationLink("", destination: UserInfoView(), isActive: $authViewModel.navigateToUserInfo)
                    .hidden()
            }
            .padding()
        }
    }
}



// 🔥 Preview for VerificationView
struct VerificationView_Previews: PreviewProvider {
    static var previews: some View {
        VerificationView(email: "test@example.com")
            .environmentObject(AuthViewModel()) // Provide Environment Object
    }
}

