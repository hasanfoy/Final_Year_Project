//
//  HistoryView.swift
//  fit
//
//  Created by Foysal Hasan on 10/02/2025.

import SwiftUI

struct HistoryView: View {
    @State private var selectedDate = Date()
    
    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()
            
            VStack(spacing: 15) {
                Text("Calendar")
                    .font(.headline)
                    .foregroundColor(.white)
                
                // **Calendar Picker**
                DatePicker("", selection: $selectedDate, displayedComponents: .date)
                    .datePickerStyle(.graphical)
                    .accentColor(.orange)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 15).fill(Color.black.opacity(0.3)))
                    .padding(.horizontal)
                    .colorScheme(.dark) // ✅ Forces dark mode
                    
                
                Text("Plans Today")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding(.top, 10)
                
                // **Workout Plans Placeholder**
                VStack(spacing: 10) {
                    WorkoutPlanCard(title: "Running", duration: "30 minutes")
                    WorkoutPlanCard(title: "Push ups", duration: "30 minutes", reps: "115", sets: "15", exercise: "5")
                }
                
                Spacer()
                
                // **Add a Plan Button**
                Button(action: {
                    print("Add Plan Tapped!") // Placeholder for now
                }) {
                    HStack {
                        Image(systemName: "plus")
                        Text("Add a plan")
                    }
                    .foregroundColor(.orange)
                    .padding()
                    .frame(width: 200)
                    .background(RoundedRectangle(cornerRadius: 15).stroke(Color.orange, lineWidth: 2))
                }
                .padding(.bottom, 20)
            }
        }
    }
}

// **Reusable Workout Card**
struct WorkoutPlanCard: View {
    var title: String
    var duration: String
    var reps: String? = nil
    var sets: String? = nil
    var exercise: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.headline)
                .bold()
                .foregroundColor(.white)
            
            HStack {
                Text("Duration: \(duration)")
                    .foregroundColor(.gray)
                
                if let reps = reps, let sets = sets, let exercise = exercise {
                    Text("Reps: \(reps)")
                        .foregroundColor(.gray)
                    Text("Sets: \(sets)")
                        .foregroundColor(.gray)
                    Text("Exercise: \(exercise)")
                        .foregroundColor(.gray)
                }
                
                Spacer()
                
                Text("Edit plan")
                    .foregroundColor(.green)
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.black.opacity(0.8)]), startPoint: .leading, endPoint: .trailing))
        .cornerRadius(15)
        .padding(.horizontal, 20)
    }
}

// **Preview**
struct HistoryView_Previews: PreviewProvider {
    static var previews: some View {
        HistoryView()
    }
}


