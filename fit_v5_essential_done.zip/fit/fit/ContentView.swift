//
//  ContentView.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var authViewModel: AuthViewModel

    var body: some View {
        NavigationStack {
            if authViewModel.isLoggedIn {
                CustomTabBarView() // ✅ If logged in, show HomeView
            } else {
                LoginView() // ✅ Otherwise, show LoginView
            }
        }
    }
}

// 🔥 Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AuthViewModel()) // ✅ Required for previews
    }
}

