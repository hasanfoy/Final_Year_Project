//
//  ExerciseTrackingView.swift
//  fit
//
//  Created by Foysal Hasan on 13/02/2025.
//
import SwiftUI

struct ExerciseTrackingView: View {
    @EnvironmentObject var exerciseVM: ExerciseViewModel
    @EnvironmentObject var navigationManager: NavigationManager

    var body: some View {
        ZStack {
            Color(hex: "060218").ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("\(exerciseVM.selectedExercise) Tracking")
                    .font(.title2)
                    .foregroundColor(.white)

                // **Progress Ring**
                ZStack {
                    Circle()
                        .stroke(Color.gray.opacity(0.3), lineWidth: 10)
                        .frame(width: 180, height: 180)

                    Circle()
                        .trim(from: 0.0, to: CGFloat(exerciseVM.progress))
                        .stroke(Color.blue, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .frame(width: 180, height: 180)
                        .animation(.linear, value: exerciseVM.progress)

                    VStack {
                        if exerciseVM.selectedOption == "Time" {
                            Text("\(exerciseVM.formattedTimeLeft)")
                                .font(.largeTitle)
                                .foregroundColor(.white)
                        } else {
                            Text("\(exerciseVM.elapsedDistanceFormatted)")
                                .font(.largeTitle)
                                .foregroundColor(.white)
                        }
                    }
                }

                // **Fancy Stat Boxes**
                VStack(spacing: 10) {
                    HStack(spacing: 15) {
                        StatBox(icon: "speedometer", title: "Live Pace", value: String(format: "%.2f min/km", exerciseVM.pace))

                        StatBox(icon: "flame.fill", title: "Calories", value: String(format: "%.1f kcal", exerciseVM.caloriesBurned))
                    }
                    
                    HStack(spacing: 15) {
                        StatBox(icon: "timer", title: "Elapsed Time", value: exerciseVM.formattedElapsedTime)
                        StatBox(icon: "location.fill", title: exerciseVM.selectedOption == "Time" ? "Elapsed Distance" : "Target Distance",
                                value: exerciseVM.selectedOption == "Time" ? exerciseVM.elapsedDistanceFormatted : String(format: "%.2f km", exerciseVM.distance))
                    }
                }
                .padding(.horizontal)

                // **Control Buttons**
                HStack {
                    Button("Finish") {
                        exerciseVM.endWorkout()
                        navigationManager.push("WorkoutSummary")
                    }
                    
                    Button(exerciseVM.isRunning ? "Pause" : "Resume") {
                        exerciseVM.isRunning ? exerciseVM.pauseWorkout() : exerciseVM.resumeWorkout()
                    }
                }
                .padding(.top, 20)

                Spacer()
            }
            .padding()
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            exerciseVM.startWorkout()
        }
    }
}















