//
//  navigationManager.swift
//  fit
//
//  Created by Foysal Hasan on 14/02/2025.
//
import Foundation
import SwiftUI

class NavigationManager: ObservableObject {
    @Published var path: [String] = []
    
    func push(_ view: String) { path.append(view) }
    func popToRoot() { path.removeAll() }
}

