//
//  AuthManager.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

class AuthViewModel: ObservableObject {
    @Published var user: User?
    @Published var isVerified = false
    @Published var isLoggedIn = false
    @Published var navigateToVerification = false
    @Published var navigateToUserInfo = false
    @Published var currentUserEmail: String = ""
    @Published var fetchedUserName: String? = nil

    private let auth = Auth.auth()
    private let db = Firestore.firestore()

    init() {
        self.user = auth.currentUser
        checkLoginStatus()
    }
    
    func updateWeightAndHeight(newWeight: Double, newHeight: Double, completion: @escaping (Bool, String?) -> Void) {
        guard let user = Auth.auth().currentUser else {
            completion(false, "User not authenticated.")
            return
        }
        
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)
        
        // Create a new weight entry
        let newWeightEntry: [String: Any] = [
            "weight": newWeight,
            "date": Timestamp(date: Date())
        ]
        
        userRef.updateData([
            "weight": newWeight,
            "height": newHeight,
            "currentWeight": newWeight, // Optional, if you store currentWeight separately
            "weightHistory": FieldValue.arrayUnion([newWeightEntry])
        ]) { error in
            if let error = error {
                print("❌ Error updating weight and height: \(error.localizedDescription)")
                completion(false, error.localizedDescription)
            } else {
                print("✅ Successfully updated weight, height, and pushed to weight history!")
                completion(true, nil)
            }
        }
    }



    func checkLoginStatus() {
        if let user = auth.currentUser {
            self.user = user
            self.isVerified = user.isEmailVerified
            self.isLoggedIn = user.isEmailVerified
        } else {
            self.isLoggedIn = false
        }
    }

    func signUp(email: String, password: String, name: String, completion: @escaping (Bool, String) -> Void) {
        print("🔥 DEBUG: Attempting to create user...")

        auth.createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                print("❌ SignUp Error: \(error.localizedDescription)")
                completion(false, "Sign-Up Failed: \(error.localizedDescription)")
                return
            }

            guard let user = result?.user else {
                completion(false, "User creation failed.")
                return
            }

            print("✅ DEBUG: User created successfully. Sending verification email...")

            // ✅ Save name to Firestore and update Firebase Auth displayName
            let userData: [String: Any] = [
                "email": user.email ?? "",
                "fullName": name,
                "uid": user.uid,
                "createdAt": Timestamp()
            ]

            self.db.collection("users").document(user.uid).setData(userData) { error in
                if let error = error {
                    print("❌ Firestore Save Error: \(error.localizedDescription)")
                    completion(false, "Failed to save user data: \(error.localizedDescription)")
                    return
                }

                print("✅ Firestore user data saved successfully!")

                // ✅ Update Firebase Auth displayName
                let changeRequest = user.createProfileChangeRequest()
                changeRequest.displayName = name
                changeRequest.commitChanges { error in
                    if let error = error {
                        print("❌ Firebase Auth displayName update error: \(error.localizedDescription)")
                        completion(false, "Failed to update display name: \(error.localizedDescription)")
                        return
                    }

                    print("✅ Firebase Auth displayName updated successfully!")

                    // ✅ Send verification email
                    user.sendEmailVerification { error in
                        DispatchQueue.main.async {
                            if let error = error {
                                print("❌ ERROR: Verification Email Failed: \(error.localizedDescription)")
                                completion(false, "Verification Email Failed: \(error.localizedDescription)")
                                return
                            }

                            print("✅ DEBUG: Verification email sent successfully!")
                            self.navigateToVerification = true
                            completion(true, "Verification email sent. Please check your inbox!")
                        }
                    }
                }
            }
        }
    }

    func checkEmailVerification(completion: @escaping (Bool) -> Void) {
        guard let user = auth.currentUser else {
            print("❌ ERROR: No user logged in.")
            completion(false)
            return
        }

        user.reload { error in
            if let error = error {
                print("❌ ERROR: Failed to reload user: \(error.localizedDescription)")
                completion(false)
                return
            }

            if user.isEmailVerified {
                print("✅ DEBUG: User has verified email! Saving to Firestore...")

                let userData: [String: Any] = [
                    "email": user.email ?? "",
                    "fullName": user.displayName ?? "New User",
                    "uid": user.uid,
                    "createdAt": Timestamp()
                ]

                self.db.collection("users").document(user.uid).setData(userData, merge: true) { error in
                    if let error = error {
                        print("❌ Firestore Save Error: \(error.localizedDescription)")
                        completion(false)
                    } else {
                        print("✅ Firestore user data saved successfully!")
                        DispatchQueue.main.async {
                            self.isVerified = true
                            self.isLoggedIn = true
                        }
                        completion(true)
                    }
                }
            } else {
                print("❌ DEBUG: User has NOT verified email yet.")
                completion(false)
            }
        }
    }

    func saveUserInfo(fullName: String, age: Int) {
        guard let user = auth.currentUser else { return }

        db.collection("users").document(user.uid).setData([
            "email": user.email ?? "",
            "fullName": fullName,
            "age": age
        ]) { error in
            if error == nil {
                DispatchQueue.main.async {
                    self.isLoggedIn = true // ✅ Move to Home after saving info
                }
            }
        }
    }

    func login(email: String, password: String, completion: @escaping (Bool, String?) -> Void) {
        auth.signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(false, error.localizedDescription)
                return
            }

            guard let user = result?.user else {
                completion(false, "Login failed. Try again.")
                return
            }

            if !user.isEmailVerified {
                print("❌ ERROR: User is not verified!")
                completion(false, "Please verify your email before logging in.")
                return
            }

            DispatchQueue.main.async {
                self.isLoggedIn = true
                self.currentUserEmail = user.email ?? ""
            }
            completion(true, nil)
        }
    }

    func updateAuthDisplayName(_ newName: String) {
        guard let user = auth.currentUser else { return }

        let changeRequest = user.createProfileChangeRequest()
        changeRequest.displayName = newName
        changeRequest.commitChanges { error in
            if let error = error {
                print("Failed to update Firebase Auth displayName: \(error.localizedDescription)")
            } else {
                print("✅ Firebase Auth displayName updated successfully!")
            }
        }
    }

    func fetchLatestUserInfo() {
        guard let user = Auth.auth().currentUser else {
            print("❌ Error: No authenticated user found.")
            return
        }

        let userId = user.uid
        let userRef = db.collection("users").document(userId)

        userRef.getDocument { (document, error) in
            if let document = document, document.exists {
                if let fullName = document.data()?["fullName"] as? String {
                    DispatchQueue.main.async {
                        self.fetchedUserName = fullName // ✅ Store fetched name
                        self.updateAuthDisplayName(fullName) // ✅ Sync with Firebase Auth
                        print("✅ Fetched User Name: \(fullName)")
                    }
                }
            } else {
                print("❌ Firestore Error: \(error?.localizedDescription ?? "User data not found.")")
            }
        }
    }

    func logout() {
        do {
            try auth.signOut()
            self.user = nil
            self.isLoggedIn = false
            self.isVerified = false
            self.navigateToVerification = false
            self.navigateToUserInfo = false
            print("✅ DEBUG: User logged out successfully.")
        } catch {
            print("❌ DEBUG: Logout failed with error: \(error.localizedDescription)")
        }
    }

    func resetPassword(email: String, completion: @escaping (Bool, String) -> Void) {
        print("Forgot Password: Attempting to send reset link...")

        auth.sendPasswordReset(withEmail: email) { error in
            if let error = error {
                print("Forgot Password Error: \(error.localizedDescription)")
                completion(false, "Failed to send reset link: \(error.localizedDescription)")
            } else {
                print("Forgot Password: Reset email sent!")
                completion(true, "Reset link sent! Check your email.")
            }
        }
    }
}

