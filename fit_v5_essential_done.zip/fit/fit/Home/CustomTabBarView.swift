//
//  CustomTabBarView.swift
//  fit
//
//  Created by Foysal Hasan on 09/02/2025.
//
import SwiftUI

struct CustomTabBarView: View {
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            WorkoutView()
                .tabItem {
                    Image(systemName: "figure.walk")
                    Text("Activity")
                }
            HistoryView()
                .tabItem {
                    Image(systemName: "calendar")
                    Text("History")
                }
            EssentialsView()
                .tabItem {
                    Image(systemName: "plus.circle.fill")
                    Text("Essential")
                }
            
            UserProfileView()
                    .tabItem {
                        Image(systemName: "person.fill")
                        Text("Profile")
                    }
            
        }
        .accentColor(.white)
    }
}

// **Preview**
struct CustomTabBarView_Previews: PreviewProvider {
    static var previews: some View {
        CustomTabBarView()
            .environmentObject(AuthViewModel())
    }
}

