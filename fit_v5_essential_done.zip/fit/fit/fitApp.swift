//
//  fitApp.swift
//  fit
//
//  Created by Foysal Hasan on 08/02/2025.
//

import SwiftUI
import Firebase

@main
struct fitApp: App {
    @StateObject var authViewModel = AuthViewModel() // ✅ Global authentication state

    init() {
        FirebaseApp.configure() // ✅ Initialize Firebase
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(authViewModel) // ✅ Pass the view model
        }
    }
}

