//
//  goalView.swift
//  fit
//
//  Created by Foysal Hasan on 13/04/2025.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct GoalsView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var goals: [Goal] = []
    @State private var showToast = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "060218").ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Text("Goal View")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.top, 10)
                    
                    NavigationLink(destination: EditGoalView(goal: Goal(id: UUID().uuidString, title: "", description: "", createdAt: Date()), isNewGoal: true, onSave: fetchGoals).environmentObject(authViewModel)) {
                        HStack {
                            Text("Add your dreams")
                                .foregroundColor(.white)
                            Spacer()
                            Image(systemName: "plus")
                                .foregroundColor(.green)
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.purple.opacity(0.7), lineWidth: 2)
                        )
                        .padding(.horizontal)
                    }
                    
                    Text("Goal List")
                        .font(.title3)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.top, 10)
                    
                    if goals.isEmpty {
                        Spacer()
                        Text("No goals yet. Tap + to add your dreams!")
                            .foregroundColor(.gray)
                            .font(.body)
                            .padding(.top, 50)
                        Spacer()
                    } else {
                        List {
                            ForEach(goals.sorted(by: { $0.createdAt > $1.createdAt })) { goal in
                                NavigationLink(destination: EditGoalView(goal: goal, isNewGoal: false, onSave: fetchGoals).environmentObject(authViewModel)) {
                                    HStack {
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text("On")
                                                .font(.caption)
                                                .foregroundColor(.white)
                                            
                                            Text(goal.createdAt, format: .dateTime.day().month().year())
                                                .font(.caption2)
                                                .foregroundColor(.white)
                                        }
                                        
                                        Spacer()
                                        
                                        Text(goal.title)
                                            .foregroundColor(.white)
                                            .bold()
                                    }
                                    .padding()
                                    .background(
                                        LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.black]), startPoint: .leading, endPoint: .trailing)
                                            .cornerRadius(10)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(Color.purple.opacity(0.7), lineWidth: 1)
                                            )
                                    )
                                }
                                .listRowBackground(Color.clear)
                            }
                            .onDelete(perform: deleteGoal) // 👈 Swipe to delete here
                        }
                        .listStyle(PlainListStyle())
                        .background(Color.clear)
                    }
                }
                .padding()
                
                // ✅ Small toast at bottom
                if showToast {
                    VStack {
                        Spacer()
                        Text("Goal Deleted!")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.green.opacity(0.8))
                            .cornerRadius(10)
                            .padding(.bottom, 40)
                    }
                    .transition(.move(edge: .bottom))
                    .animation(.easeInOut, value: showToast)
                }
            }
        }
        .onAppear {
            fetchGoals()
        }
    }
    
    private func fetchGoals() {
        guard let user = authViewModel.user else { return }
        
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)
        
        userRef.getDocument { document, error in
            if let document = document, document.exists {
                if let goalArray = document.data()?["goals"] as? [[String: Any]] {
                    self.goals = goalArray.compactMap { Goal(dict: $0) }
                }
            } else {
                print("❌ Error fetching goals: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }
    
    private func deleteGoal(at offsets: IndexSet) {
        guard let index = offsets.first else { return }
        let goal = goals.sorted(by: { $0.createdAt > $1.createdAt })[index]
        
        guard let user = authViewModel.user else { return }
        
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(user.uid)
        
        userRef.getDocument { document, error in
            if let document = document, document.exists {
                var currentGoals = document.data()?["goals"] as? [[String: Any]] ?? []
                
                currentGoals.removeAll { $0["id"] as? String == goal.id }
                
                userRef.updateData([
                    "goals": currentGoals
                ]) { error in
                    if let error = error {
                        print("❌ Error deleting goal: \(error.localizedDescription)")
                    } else {
                        print("✅ Goal deleted successfully!")
                        fetchGoals()
                        showDeletedToast()
                    }
                }
            }
        }
    }
    
    private func showDeletedToast() {
        showToast = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            showToast = false
        }
    }
}



struct GoalsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            GoalsView()
                .environmentObject(AuthViewModel()) 
        }
    }
}
